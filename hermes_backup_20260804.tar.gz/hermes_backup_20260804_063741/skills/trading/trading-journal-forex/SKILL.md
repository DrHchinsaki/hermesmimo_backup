---
name: trading-journal-forex
description: "Record forex trades, track PnL and store screenshots."
version: 1.0.0
created_by: agent
---

# Trading Journal (Forex)

## Use When
- User wants to record a new trade entry (entry, TP, SL, strategy, mindset)
- User wants to store a screenshot alongside the trade
- User wants to record the result (win/loss, PnL)
- User wants to generate a performance summary or report
- User wants to track statistics over time

## Workflow

### Step 1: Receive trade entry
Parse user data into:

| Field | Example |
|-------|---------|
| Pair | `XAUUSD`, `EURUSD` |
| Direction | `BUY` / `SELL` |
| Entry price | `4089.79` |
| TP | `4021.62` |
| SL | `4098.26` |
| Strategy | `بر مبنای روند` |
| Mindset | `متمرکز و آرام` |
| Screenshot | attached image |

Save screenshot: `screenshots/trade_<id>_<pair>.jpg`

### Step 2: Register with journal script
```bash
cd /data/.hermes/trading_journal/scripts
python3 add_trade.py add <PAIR> <DIRECTION> <ENTRY> <TP> <SL> "<STRATEGY>" "<MINDSET>" [screenshot_path]
```

### Step 3: Record result when trade closes
User reports exit price, win/loss, PnL. Use Python to update `trades.json`.

### Step 4: Generate summary on demand
```bash
cd /data/.hermes/trading_journal/scripts
python3 generate_report.py summary
```

## Critical Pitfalls

### 1. Do NOT Analyze the Trade at Entry
Record only. No chart interpretation, no TP/SL suggestions, no market commentary.

**User Correction:** "اسکرین شات رو برات نفرستادم که تحلیل کنی، من ازت تحلیل نمی‌خوام برای معاملاتم، بهت دادم تا ثبت کنی که بعداً بتونیم آنالیز کنیم پوزیشن های من رو"

When user sends a new position with screenshot:
1. ✅ **RECORD** the trade data (entry, TP, SL, strategy, mindset, screenshot)
2. ✅ Copy screenshot to `~/.hermes/trading_journal/screenshots/`
3. ❌ **DO NOT** provide technical analysis, RSI readings, or trading advice
4. ❌ **DO NOT** analyze the screenshot beyond noting it exists
5. ✅ Simply confirm: "ثبت شد!" with the recorded data table

The user will request analysis later when they want it. Recording is the ONLY job at position entry.

### 2. Do NOT Comment on PnL
No "good trade" / "bad trade" — just record the numbers.

### 3. Do NOT Over-Format
Clean tables. `#Trade` in private, `#News` in group.

### 4. Always Store Screenshots if Provided

### 5. Tehran timezone (UTC+3:30) for all timestamps

## User Preferences
- Persian (Farsi) for trade communication
- Hashtags: `#Trade` private, `#News` group
- Tehran timezone
- Zero analytical depth — record only
- Anti-spam: silent when no trades exist

## Data Structure

```json
{
  "trades": [
    {
      "id": 1,
      "pair": "EURUSD",
      "direction": "BUY",
      "entry": 1.0850,
      "tp": 1.0900,
      "sl": 1.0800,
      "exit": 1.0900,
      "result": "WIN",
      "pips": 50,
      "strategy": "Breakout",
      "mindset": "Focused and calm",
      "screenshot": "path/to/screenshot.jpg",
      "status": "closed",
      "opened_at": "2026-07-26T10:00:00",
      "closed_at": "2026-07-26T14:00:00"
    }
  ],
  "stats": {
    "total_trades": 10,
    "wins": 6,
    "losses": 4,
    "win_rate": 60.0,
    "total_pips": 250
  }
}
```

## Reference Files
- `references/trade-input-format.md` — User input format examples
- `references/report-generation.md` — Performance report patterns
