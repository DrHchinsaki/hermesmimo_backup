# Telegram Group Delivery Patterns

## Delivery Configuration

### Dual Delivery (DM + Group)
```python
deliver="origin,telegram:-1004281458610"
```

### Group-Only Delivery
```python
deliver="telegram:-1004281458610"
```

### DM-Only Delivery
```python
deliver="telegram"
```

## Hashtag Rules

### Group Messages
- ONLY use `#News` hashtag
- Do NOT use other hashtags in group
- Keep messages concise

### DM Messages
- Use full hashtag set for filtering:
  - `#econweekly` — Weekly economic summary
  - `#econalerts` — Real-time economic alerts
  - `#forexnews` — Forex news
  - `#backup` — Backup reports
  - `#dailytasks` — Daily tasks
  - `#reminder` — Task reminders
  - `#dailyreport` — Daily reports
  - `#weight` — Weight tracking
  - `#calories` — Calorie tracking
  - `#trading` — Trading journal

## Anti-Spam Rules

### [SILENT] Pattern
When there's nothing to report, respond with EXACTLY:
```
[SILENT]
```
This suppresses ALL delivery to both DM and group.

### Never Send Empty Messages
If the script output is empty or shows no new data, do NOT send a message. Use `[SILENT]` to suppress delivery.

## Group Privacy
- Bot SENDS messages to group ✅
- Bot does NOT read/monitor group messages ❌
- User communicates with bot via DM only
- If user wants to send to group, they tell bot in DM

## Message Formatting

### Economic Events
```
📰 **NEWS FEED - DIGEST**

🔄 [count] New Stories

🔴/🟡/🔵 **[Title]**
📌 Source: [source]
💡 Impact: [impact] | Category: [category]
```

### Real-time Alerts
```
🔔 **ECONOMIC EVENT UPDATE**

📅 [Event Name]
🏦 [Currency]
⏰ [Time]
📊 Result: [Actual] (Forecast: [Forecast], Previous: [Previous])

💡 **Market Impact:**
- [Currency pair analysis]
- [Gold/Oil impact]
```
