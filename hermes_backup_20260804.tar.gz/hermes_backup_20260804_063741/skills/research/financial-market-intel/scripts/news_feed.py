#!/usr/bin/env python3
"""
News Feed - Multi-source financial news aggregator.
Fetches from Forex Factory calendar.
Stores news in /data/.hermes/news_feed/news.json
ONLY shows UPCOMING events (not past ones).
"""
import urllib.request
import json
import os
import sys
from datetime import datetime, timedelta, timezone

DATA_DIR = "/data/.hermes/news_feed"
NEWS_FILE = os.path.join(DATA_DIR, "news.json")

def load_news():
    if os.path.exists(NEWS_FILE):
        with open(NEWS_FILE, "r") as f:
            return json.load(f)
    return {"stories": [], "last_fetch": None}

def save_news(data):
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(NEWS_FILE, "w") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def fetch_forex_factory_calendar():
    """Fetch high/medium impact events from Forex Factory - UPCOMING ONLY."""
    url = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
    headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"}
    stories = []
    now = datetime.now(timezone.utc)
    
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            for event in data:
                if event.get("impact") not in ["High", "Medium"]:
                    continue
                
                # Parse event date and filter for upcoming events only
                event_date_str = event.get("date", "")
                if event_date_str:
                    try:
                        event_date = datetime.fromisoformat(event_date_str.replace("Z", "+00:00"))
                        if event_date < (now - timedelta(hours=2)):
                            continue  # Skip past events
                    except:
                        pass
                
                stories.append({
                    "title": f"{event.get('title', 'Unknown')} - {event.get('currency', '')}",
                    "source": "Forex Factory",
                    "category": "economic-calendar",
                    "impact": event.get("impact", "Medium"),
                    "date": event_date_str,
                    "forecast": event.get("forecast", ""),
                    "previous": event.get("previous", ""),
                    "actual": event.get("actual", ""),
                    "url": "https://www.forexfactory.com/calendar"
                })
    except Exception as e:
        print(f"Error fetching Forex Factory: {e}", file=sys.stderr)
    return stories

def fetch_all():
    """Fetch from all sources and store."""
    news = load_news()
    existing_titles = {s["title"] for s in news["stories"]}
    
    new_stories = fetch_forex_factory_calendar()
    
    added = 0
    for story in new_stories:
        if story["title"] not in existing_titles:
            story["fetched_at"] = datetime.utcnow().isoformat()
            news["stories"].append(story)
            existing_titles.add(story["title"])
            added += 1
    
    news["last_fetch"] = datetime.utcnow().isoformat()
    save_news(news)
    
    print(json.dumps({"new": added, "total": len(news["stories"])}, ensure_ascii=False))

def stats():
    """Show statistics."""
    news = load_news()
    sources = {}
    for s in news["stories"]:
        src = s.get("source", "Unknown")
        sources[src] = sources.get(src, 0) + 1
    print(json.dumps({"total": len(news["stories"]), "by_source": sources, "last_fetch": news.get("last_fetch")}, ensure_ascii=False, indent=2))

def main():
    if len(sys.argv) < 2:
        print("Usage: news_feed.py [fetch|stats]")
        sys.exit(1)
    
    cmd = sys.argv[1]
    
    if cmd == "fetch":
        fetch_all()
    elif cmd == "stats":
        stats()
    else:
        print(f"Unknown command: {cmd}")
        sys.exit(1)

if __name__ == "__main__":
    main()
