# Web Search Fallback Catalog

## Working Search Endpoints (Verified August 2026)

### 1. Google News RSS (Most Reliable)
```bash
curl -sL "https://news.google.com/rss/search?q=URL_ENCODED_QUERY&hl=en&gl=US&ceid=US:en" \
  -A "Mozilla/5.0" | grep -oP '<title>[^<]*</title>|<link>[^<]*</link>|<pubDate>[^<]*</pubDate>'
```
- Returns structured XML: title, link (Google redirect), pubDate
- Google redirect URLs need to be fetched to get the actual article
- Works reliably from server IPs
- Supports date ranges, topic filters, language selection

### 2. Google Scholar (Academic)
```bash
curl -sL "https://scholar.google.com/scholar?q=QUERY&hl=en" \
  -A "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0" \
  | grep -oP 'href="(https?://[^"]*)"' | grep -v 'google\.\|scholar\.\|gstatic'
```
- Returns paper links from journals, SSRN, HAL, AEA, etc.
- Pair with `arxiv` skill for arXiv paper retrieval

### 3. ECB SDMX Data API (Financial Data)

**EUR/USD exchange rate (last 30 days):**
```bash
curl -sL "https://data-api.ecb.europa.eu/service/data/EXR/D.USD.EUR.SP00.A?format=jsondata&lastNObservations=30"
```

**Parse with shell (no python pipe needed):**
```bash
curl -sL "URL_ABOVE" -o ecb_data.json
python3 -c "
import json
data = json.load(open('ecb_data.json'))
series = data['dataSets'][0]['series']
obs_dims = data['structure']['dimensions']['observation'][0]['values']
values = list(series.values())[0]['observations']
for key, val in values.items():
    print(f'{obs_dims[int(key)][\"id\"]}: {val[0]:.4f}')
"
```

**Other ECB series:**
- `EXR.D.GBP.EUR.SP00.A` — GBP/EUR
- `EXR.D.JPY.EUR.SP00.A` — JPY/EUR
- `EXR.D.CHF.EUR.SP00.A` — CHF/EUR

### 4. National Bank of Belgium (NBB)
- Exchange rates: `https://www.nbb.be/en/about-national-bank/eurosystem/exchange-rates`
- Annual reports: `https://www.nbb.be/en/publications-research/publications/all-publications/`
- Works with curl, returns HTML with grep-able content

### 5. arXiv API
```bash
curl -s "https://export.arxiv.org/api/query?search_query=all:QUERY&max_results=5"
```
- Returns Atom XML, no auth needed
- See `arxiv` skill for full details

### 6. Semantic Scholar API
```bash
curl -s "https://api.semanticscholar.org/graph/v1/paper/search?query=QUERY&limit=5&fields=title,authors,year,citationCount"
```
- Returns JSON, 1 req/sec without API key
- Supports citation graphs, author profiles, recommendations

## Known Blockers (Do NOT Retry)

| Service | Block Type | Notes |
|---------|-----------|-------|
| DuckDuckGo HTML | CAPTCHA | Server IP detection — consistent |
| Brave Search HTML | JS-rendered + bot detection | No server-side rendering for curl |
| SearXNG instances | Anubis/CAPTCHA challenge | Most instances now use anti-bot |
| Taylor & Francis | Cloudflare JS challenge | Academic journal paywall |
| HAL Science | Anubis proof-of-work | French open archive |
| Reuters | Paywall / JS rendering | Needs browser session |

## Article Fetching Notes
- Use Firefox UA: `Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0`
- Some sites return full article text in HTML (Courthouse News, NBB, ECB)
- For JS-heavy sites, extract from `<script>` tags or `__APP_STATE__` JSON blobs
- Use `grep -i "keywords" | sed 's/<[^>]*>//g'` to extract text from HTML
- Always check for 404 or "Page not found" before treating content as valid
