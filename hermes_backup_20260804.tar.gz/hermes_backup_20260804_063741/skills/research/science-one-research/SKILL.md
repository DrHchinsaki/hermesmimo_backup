---
name: science-one-research
description: "Research with evidence chains. Use to investigate topics."
version: 1.0.0
created_by: agent
---

# Science One Research Framework

Based on Google Science One (July 2026). Chain-of-Evidence for verifiable research.

## When to Use
- User asks to research or investigate a topic
- User asks "is this true?" or fact-checks a claim
- User wants literature review or market analysis

## Core Principle
Every claim MUST have an evidence chain:
1. Completeness: Every claim links to a source
2. Correctness: Source must support the claim

## Workflow

### Phase 1: Literature Grounding
1. Identify key questions
2. Search using web_search and arXiv skill
3. Build source inventory with URLs
4. Read top 5-10 sources fully

### Phase 2: Evidence Collection
For each claim:
- Tag: [CLAIM-1], [CLAIM-2]
- Link evidence sources
- Note confidence: HIGH/MEDIUM/LOW
- Check for contradictions

### Phase 3: Report with Inline Evidence
```
## [Topic]
[CLAIM-1] Finding here.^[1][2]

---
## Sources
[1] Source title — URL
```

### Phase 4: Self-Audit
1. Reference Check: Do URLs exist?
2. Claim Check: Every claim has evidence?
3. Freshness Check: Sources recent enough?
4. Bias Check: Multiple perspectives?

## Output Language
- Persian user → Persian report
- English user → English report

## Never Do
- Cite from memory without searching
- Present unverified claims as facts
- Fabricate URLs or paper titles
- Skip evidence tags

## Source
Google Research: https://research.google/blog/science-one-framework-a-verifiable-autonomous-research-framework-via-chain-of-evidence/
