#!/usr/bin/env python3
"""
News Feed - Multi-source financial news aggregator.
Fetches from Forex Factory calendar and news.
Stores news in /data/.hermes/news_feed/news.json
Usage: news_feed.py [fetch|recent|source|stats]
"""
import urllib.request
import json
import os
import sys
from datetime import datetime, timedelta

DATA_DIR = "/data/.hermes/news_feed"
NEWS_FILE = os.path.join(DATA_DIR, "news.json")

def load_news():
    if os.path.exists(NEWS_FILE):
        with open(NEWS_FILE, "r") as f:
            return json.load(f)
    return {"stories": [], "last_fetch": None}

def save_news(data):
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(NEWS_FILE, "w") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def fetch_forex_factory_calendar():
    url = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
    headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"}
    stories = []
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            for event in data:
                if event.get("impact") in ["High", "Medium"]:
                    stories.append({
                        "title": f"{event.get('title', 'Unknown')} - {event.get('currency', '')}",
                        "source": "Forex Factory",
                        "category": "economic-calendar",
                        "impact": event.get("impact", "Medium"),
                        "date": event.get("date", ""),
                        "forecast": event.get("forecast", ""),
                        "previous": event.get("previous", ""),
                        "actual": event.get("actual", ""),
                        "url": "https://www.forexfactory.com/calendar"
                    })
    except Exception as e:
        print(f"Error fetching Forex Factory: {e}", file=sys.stderr)
    return stories

def fetch_forex_news():
    url = "https://www.forexfactory.com/news"
    headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"}
    stories = []
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=30) as resp:
            html = resp.read().decode("utf-8", errors="ignore")
            import re
            titles = re.findall(r'class="title"[^>]*>([^<]+)<', html)
            for title in titles[:10]:
                stories.append({
                    "title": title.strip(),
                    "source": "Forex Factory",
                    "category": "news",
                    "impact": "Medium",
                    "url": "https://www.forexfactory.com/news"
                })
    except Exception as e:
        print(f"Error fetching FF news: {e}", file=sys.stderr)
    return stories

def fetch_all():
    news = load_news()
    existing_titles = {s["title"] for s in news["stories"]}
    new_stories = fetch_forex_factory_calendar() + fetch_forex_news()
    added = 0
    for story in new_stories:
        if story["title"] not in existing_titles:
            story["fetched_at"] = datetime.utcnow().isoformat()
            news["stories"].append(story)
            existing_titles.add(story["title"])
            added += 1
    news["last_fetch"] = datetime.utcnow().isoformat()
    save_news(news)
    print(json.dumps({"new": added, "total": len(news["stories"])}, ensure_ascii=False))

def recent(hours=24):
    news = load_news()
    cutoff = (datetime.utcnow() - timedelta(hours=hours)).isoformat()
    r = [s for s in news["stories"] if s.get("fetched_at", "") >= cutoff]
    print(json.dumps({"count": len(r), "stories": r}, ensure_ascii=False, indent=2))

def by_source(name):
    news = load_news()
    f = [s for s in news["stories"] if s.get("source", "").lower() == name.lower()]
    print(json.dumps({"count": len(f), "stories": f}, ensure_ascii=False, indent=2))

def stats():
    news = load_news()
    sources = {}
    for s in news["stories"]:
        src = s.get("source", "Unknown")
        sources[src] = sources.get(src, 0) + 1
    print(json.dumps({"total": len(news["stories"]), "by_source": sources, "last_fetch": news.get("last_fetch")}, ensure_ascii=False, indent=2))

def main():
    if len(sys.argv) < 2:
        print("Usage: news_feed.py [fetch|recent|source|stats]")
        sys.exit(1)
    cmd = sys.argv[1]
    if cmd == "fetch": fetch_all()
    elif cmd == "recent": recent(int(sys.argv[2]) if len(sys.argv) > 2 else 24)
    elif cmd == "source":
        if len(sys.argv) < 3: print("Usage: news_feed.py source <name>"); sys.exit(1)
        by_source(sys.argv[2])
    elif cmd == "stats": stats()
    else: print(f"Unknown command: {cmd}"); sys.exit(1)

if __name__ == "__main__":
    main()
