# Sina's Setup Reference

## Backup Repo
- **Repo:** `DrHchinsaki/hermesmimo_backup`
- **URL:** https://github.com/DrHchinsaki/hermesmimo_backup
- **PAT:** Stored in `~/.hermes/scripts/backup_hermes.sh`

## Telegram
- **Personal chat_id:** `63572897`
- **Group chat_id:** `-1004281458610`
- **Group rules:** Bot sends ONLY `#News` hashtag. No reading group messages.
- **Private chat:** All hashtags OK.

## Provider
- **Model:** `My_Hermes` via `openai-api`
- All cron jobs should use the same model as the main session.

## Cron Schedule (Tehran = UTC+3:30)
| Job | UTC | Tehran |
|-----|-----|--------|
| Weight Check | 04:30 | 08:00 |
| Breakfast Calorie | 03:30 | 07:00 |
| Morning Tasks | 05:30 | 09:00 |
| Lunch Calorie | 09:30 | 13:00 |
| Dinner Calorie | 16:30 | 20:00 |
| Evening Tasks | 18:30 | 22:00 |
| Snack Check | 18:30 | 22:00 |
| Weekly Econ News | 17:30 Sun | 21:30 Sun |
| Anniversary Reminder | 18:30 16th | 22:30 16th |
| Birthday Reminder | 18:30 Jan 8-11 | 22:30 Jan 8-11 |

## Tracker Paths
- Task Manager: `~/.hermes/task_manager/scripts/task_manager.py`
- Weight Tracker: `~/.hermes/weight_tracker/scripts/weight_tracker.py`
- Calorie Tracker: `~/.hermes/calorie_tracker/scripts/calorie_tracker.py`
- News Feed: `~/.hermes/news_feed/scripts/news_feed.py`
- Trading Journal: `~/.hermes/trading_journal/`
- Shopping List: `~/.hermes/shopping_list/`
- Meetings: `~/.hermes/meetings/`

## Key Limits
- Daily calories: 2117
- Weight goal: 110kg → 80kg
- Walking: 20min minimum daily
- Exercise: daily
