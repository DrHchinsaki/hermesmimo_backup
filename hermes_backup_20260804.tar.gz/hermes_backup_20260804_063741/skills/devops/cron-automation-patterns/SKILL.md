---
name: cron-automation-patterns
description: "Cron job scheduling, rate limiting, and orchestration."
version: 1.0.0
created_by: agent
---

# Cron Automation Patterns

## Use When
- Setting up cron jobs that share an API provider
- Multiple cron jobs firing simultaneously causing rate limits
- Migrating cron jobs between providers/models
- Orchestrating delivery targets (DM vs group)
- User reports cron job failures from rate limiting

## Critical Pitfalls

### 1. Simultaneous Cron Job Execution Causes Rate Limits (CRITICAL)
When multiple cron jobs fire at the same time on the same API provider, they can exhaust free-tier limits. The error is typically `FreeUsageLimitError` or HTTP 429.

**Symptoms:**
- Some jobs succeed, others fail with rate limit errors
- Jobs that fire at `:30` or `:00` overlap with others
- More jobs = higher chance of hitting limits

**Fix — Stagger Schedules:**
```
❌ Bad:  All jobs at :30 (18:30, 18:30, 18:30)
✅ Good: Stagger by 15+ minutes (16:00, 16:30, 16:45, 17:00)
```

**Rule:** Minimum 15-minute gap between any two cron jobs using the same provider. For 10+ jobs, consider 30-minute gaps or reducing frequency.

### 2. API Rate Limiting from External Data Sources
Third-party APIs (like Forex Factory) have their own rate limits. Scripts that fetch data on tight schedules can get 429 errors.

**Fix — Implement Caching:**
- Store fetched data in a JSON cache file
- On API failure, serve from cache instead of failing
- Use cache staleness indicator so consumers know data age
- See `references/forex-factory-api.md` for endpoint-specific limits

### 3. Duplicate Functionality Detection
Before creating a new cron job, check if an existing job already covers the same data source or delivery target.

**Red Flags:**
- Two jobs fetching from the same API endpoint
- Two jobs delivering similar content to the same channel
- Job A's output being a subset of Job B's output

**Action:** Remove the redundant job immediately. User will notice and ask about it.

### 4. Delivery Target Configuration
When setting up news/information cron jobs for a user with an active Telegram group:
- Always include BOTH DM and group in `deliver`
- Format: `deliver: "origin,telegram:<group_id>"`
- Group messages should use `#News` hashtag only
- DM messages can use any hashtag

**Common Mistake:** Setting `deliver: "origin"` only, then user asks "why didn't this go to the group?"

### 5. Provider Migration Pattern (Batch Update)
When a provider fails and all cron jobs share it:
1. Test the new provider with ONE job first: `cronjob(action='run', job_id=...)`
2. If OK, batch-update ALL jobs in ONE turn (parallel calls)
3. Do NOT migrate one-by-one — user will see failures before you finish
4. Always have a known-good fallback provider ready

### 6. [SILENT] Pattern for No-News Suppression
When cron jobs have nothing to report, they must output `[SILENT]` to suppress delivery entirely. This prevents empty/spam messages.

**Script Pattern:**
```python
# Script outputs "0" when nothing new
# Cron prompt checks: if output == "0" or "NO_NEW_NEWS": respond [SILENT]
```

**Critical:** Both the script AND the cron prompt must check. Script alone suppressing isn't enough if the prompt wraps output in a message.

## Schedule Optimization Table

| Job Count | Min Gap | Recommended Pattern |
|-----------|---------|---------------------|
| 1-5 jobs | 5 min | Standard :00/:30 |
| 6-10 jobs | 15 min | Stagger :00, :15, :30, :45 |
| 11-15 jobs | 20 min | Spread across full hour |
| 16+ jobs | 30 min | Consider reducing frequency |

## Reference Files
- `references/forex-factory-api.md` — Forex Factory API endpoints and rate limits
- `references/user-sina-profile.md` — User-specific communication preferences
- `references/task-manager-cli.md` — task_manager.py CLI commands, pitfalls (empty-output commands), JSON schema, and known bugs
- `scripts/forex_factory_news.py` — Forex Factory calendar fetcher with caching
