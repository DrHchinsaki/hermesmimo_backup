# User Sina - Communication & Workflow Preferences

## Language
- **Primary:** Persian (Farsi) for text messages
- **Voice:** English only (Persian TTS quality is poor)
- Voice summaries are NOT wanted — text only

## Economic News Format Preferences
- **Weekly summary:** Persian text, event list only. For each event, include brief "if more/less" impact note (one line each). NO full market analysis.
- **Real-time alerts:** Only send when there IS something new. Use `[SILENT]` when nothing to report.
- **Hashtag in group:** ONLY `#News`
- **Hashtag in DM:** Can use any hashtag

## Trading Journal
- **DO NOT analyze** individual trades or give advice — user will report the result when done
- **DO record:** pair, direction, entry, TP, SL, strategy, mindset, screenshot
- **DO record:** result (TP/SL hit), profit/loss, notes
- **DO generate** aggregated reports/stats when asked

## Branding Agency Context
- Starting out, no prior projects
- First meeting with dental clinic investors (July 27, 2026)
- Meeting prep at: /data/.hermes/meetings/
- All services: visual identity, logo, interior design, signage, brand strategy
- **Meeting prep pattern:** Ask questions about client details → research competitors/market → create briefing document → store at `/data/.hermes/meetings/`

## Daily Routine System (built July 2026)

### Morning (8:00-9:00 Tehran)
1. **Weight check** at 8:00 — user sends number (e.g. "110.6")
2. **Morning tasks** at 9:00 — agent asks for tasks, user lists them
3. **Breakfast check** — user tells what they ate, agent estimates calories

### Midday (14:00-20:00)
- **Lunch check** at 13:00 — user reports lunch, agent logs calories
- **Task reminders** every 2 hours — 30 min before scheduled tasks

### Evening (20:00-22:00)
- **Dinner check** at 20:00 — user reports dinner, final calorie tally
- **Snack check** at 22:00 — user reports any extras
- **Evening report** at 22:00 — completion check on all daily tasks

### Calorie Tracking
- **Daily limit:** 2117 calories
- **Weight goal:** 110kg → 80kg
- Agent estimates calories from food descriptions (don't ask user for numbers)
- Warn when near/over limit (70%=warning, 90%=critical, 100%=exceeded)

### Health Must-Do's (non-negotiable daily tasks)
1. Walking/Treadmill — 20 minutes minimum
2. Exercise/Workout

## Shopping List
- Located at: /data/.hermes/shopping_list/
- **How to use:** User says "لیست خرید: [items]" → Agent adds items
- **Purchased:** User says "لیست خرید: شماره X و Y رو خریدم" → Agent removes
- Hashtag: `#shopping` (DM only)

## Reminders

### Personal
- **Anniversary:** 17th of each month — remind on the 16th at 20:00
- **Annual Anniversary:** 15 Mordad — remind on 15th and 16th
- **MahTae's birthday:** 21st of Dey (~Jan 11) — remind from Jan 8-11 at 20:00
- Keep messages simple, no full analysis — brief impact notes under events

### Group Etiquette
- Bot SENDS news to group ONLY when there's new content
- Bot does NOT read/monitor group messages (privacy)
- User triggers group sends from DM
- Hashtag in group: ONLY `#News`

## Provider Status (July 2026)
| Provider | Model | Status |
|----------|-------|--------|
| openai-api | My_Hermes | ✅ Active (stable fallback) |
| OpenRouter | various free models | ⚠️ Rate limits with 10+ cron jobs |
| Gemini (AI Studio key) | gemini-2.5-* | ❌ Auth failure (key format unsupported) |

## Cron Jobs Health
When a provider fails, migrate ALL 14 cron jobs at once using batch update. Test one `cronjob(action='run')` before walking away.
