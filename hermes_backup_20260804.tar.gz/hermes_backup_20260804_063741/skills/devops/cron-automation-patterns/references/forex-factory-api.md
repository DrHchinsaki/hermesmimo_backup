# Forex Factory API Reference

## Available Endpoints

### Economic Calendar
- **URL:** `https://nfs.faireconomy.media/ff_calendar_thisweek.json`
- **Returns:** Current week's economic events
- **Fields:** title, currency, impact (High/Medium/Low), date, forecast, previous, actual
- **Rate Limit:** ~10 requests/hour (empirical). 429 after repeated calls.
- **Caching:** Store in JSON file, serve from cache on 429

### News Stories
- **URL:** `https://www.forexfactory.com/news`
- **Returns:** HTML page (requires scraping)
- **Status:** Often returns 403 Forbidden (blocked by WAF)
- **Fallback:** Use calendar data instead

## Critical Notes

### Only Fetch UPCOMING Events
The calendar API returns ALL events for the week, including past ones. Scripts MUST filter for upcoming events only:

```python
now = datetime.now(timezone.utc)
for event in data:
    event_date = datetime.fromisoformat(event['date'].replace('Z', '+00:00'))
    if event_date < (now - timedelta(hours=2)):
        continue  # Skip past events
```

### Rate Limit Handling
```python
import time

def fetch_with_retry(url, max_retries=3, delay=60):
    for attempt in range(max_retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            if e.code == 429:
                time.sleep(delay * (attempt + 1))
            else:
                raise
    return None  # All retries failed
```

### Currency Codes
USD, EUR, GBP, JPY, CHF, CAD, AUD, NZD, CNY

### Impact Levels
- **High:** Rate decisions, NFP, CPI, GDP
- **Medium:** PMI, employment, consumer confidence
- **Low:** Minor indicators, housing data