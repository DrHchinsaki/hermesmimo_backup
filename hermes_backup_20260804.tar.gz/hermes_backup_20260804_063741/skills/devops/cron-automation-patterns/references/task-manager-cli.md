# task_manager.py CLI Reference

**Script path:** `/data/.hermes/task_manager/scripts/task_manager.py`
**Data file:** `/data/.hermes/task_manager/tasks.json` (expanduser `~/.hermes/task_manager/tasks.json`)

## Working Commands

| Command | Output | Notes |
|---------|--------|-------|
| `stats` | JSON: total, done, rate | Works correctly |
| `pending` | List of pending task IDs + text | Works correctly |

## Broken / Silent-Empty Commands

These commands exist in the script but return **empty stdout** (no error, exit 0):
- `list`
- `all`
- `show`
- `--help`

**Do not rely on them.** If you need full task data, read `tasks.json` directly.

## Reading Task Data

```python
# Fastest: read JSON directly
import json, os
path = os.path.expanduser("~/.hermes/task_manager/tasks.json")
db = json.load(open(path))

# Filter by date
today_tasks = [t for t in db["tasks"] if t["date"] == "2026-08-03"]
pending = [t for t in db["tasks"] if t["status"] == "pending"]
completed = [t for t in db["tasks"] if t["status"] == "completed"]
```

## JSON Schema

```json
{
  "tasks": [
    {
      "id": int,
      "text": str,
      "time": str|null,
      "priority": "normal",
      "status": "pending"|"completed",
      "reminder_sent": bool,
      "created_at": ISO datetime,
      "date": "YYYY-MM-DD",
      "completed_at": ISO datetime|null
    }
  ],
  "completed": [task_id, ...],
  "pending": [task_id, ...],
  "stats": {
    "total_tasks": int,
    "pending_tasks": int,
    "completed_tasks": int,
    "completion_rate": float  // may be stale if tasks added without completion
  },
  "daily_logs": {}
}
```

## Known Bug: Stale completion_rate

`add_task()` does NOT recalculate `completion_rate` in stats. When tasks are added
without any being completed, `completion_rate` remains at its previous value. Only
`complete_task()` recalculates it. For accurate rates, calculate from raw data:
```python
completed = len([t for t in db["tasks"] if t["status"] == "completed"])
total = len(db["tasks"])
rate = round(completed / total * 100, 1) if total > 0 else 0
```

## Completing Tasks

```bash
python3 /path/to/task_manager.py complete <task_id>
```
Note: `complete` command not tested in this session — verify before relying on it.
