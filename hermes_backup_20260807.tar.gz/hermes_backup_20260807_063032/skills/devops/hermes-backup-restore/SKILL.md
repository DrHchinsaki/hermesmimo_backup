---
name: hermes-backup-restore
description: "Backup and restore Hermes agent via GitHub: run backups, fix script bugs, recover from tarballs."
version: 1.0.0
created_by: agent
---

# Hermes Backup & Restore

## When to use
User provides a GitHub backup repo and asks to restore/rebuild their Hermes setup. Common scenarios: fresh server, server migration, recovering after config corruption, or switching to a new machine.

## Workflow

### Step 1: Clone the backup repo
```bash
GIT_TERMINAL_PROMPT=0 git clone https://<PAT>@github.com/<owner>/<repo>.git /data/hermesmimo_backup
```
Use HTTPS (not SSH) — port 22 may be closed on cloud servers.

### Step 2: Extract the latest backup
```bash
cd /data/hermesmimo_backup
tar -xzf hermes_backup_<date>.tar.gz
```
The extracted directory contains: SOUL.md, memory/MEMORY.md, memory/USER.md, config.yaml, cron/jobs.json, scripts/, skills/, cron/output/.

### Step 3: Read key files to understand the setup
Priority order:
1. **memory/MEMORY.md** — operational notes, cron pitfalls, provider status
2. **memory/USER.md** — full user profile (language, preferences, daily routine, workflow rules)
3. **config.yaml** — platform config (Telegram chat_id, user_id, terminal settings)
4. **SOUL.md** — personality (usually default Hermes, skip unless customized)
5. **cron/jobs.json** — all cron job definitions with prompts, schedules, scripts, delivery targets

### Step 4: Save user profile to memory
Extract durable facts from MEMORY.md and USER.md. Save to Hermes memory using `memory(action='add', target='user')` and `target='memory'`. Keep entries compact and high-signal.

### Step 5: Restore scripts to expected paths
**CRITICAL PITFALL:** Tracker scripts may NOT be in `scripts/` — they often live under `skills/*/scripts/` in the backup. Check both locations:
```bash
# Check backup scripts dir
ls hermes_backup_<date>/scripts/

# Check skills directories for tracker scripts
find hermes_backup_<date>/skills -name "task_manager.py" -o -name "weight_tracker.py" -o -name "calorie_tracker.py"
```

Copy to expected locations:
```bash
mkdir -p ~/.hermes/{scripts,task_manager/scripts,weight_tracker/scripts,calorie_tracker/scripts,news_feed/scripts}
cp <found_path> ~/.hermes/task_manager/scripts/task_manager.py
cp <found_path> ~/.hermes/weight_tracker/scripts/weight_tracker.py
cp <found_path> ~/.hermes/calorie_tracker/scripts/calorie_tracker.py
```

Also create data directories:
```bash
mkdir -p ~/.hermes/{trading_journal,meetings,shopping_list,cron/output}
```

### Step 6: Recreate cron jobs from jobs.json
Parse `cron/jobs.json` and recreate each job. Key fields per job:
- `name`, `prompt`, `schedule` (expr or interval), `script`, `deliver`, `model/provider`

For each job:
```python
cronjob(action="create",
        name=job["name"],
        schedule=job["schedule_display"],
        prompt=job["prompt"],
        script=job.get("script"),
        deliver=job["deliver"],
        model={"model": job["model"], "provider": job["provider"]})
```

**Pitfall:** `deliver` format matters. `"origin,telegram:-1004281458610"` sends to both DM and group. `"telegram"` sends only to DM. `"origin"` sends only to the originating chat. Match exactly.

### Step 7: Verify
```bash
cronjob(action="list")  # Confirm all jobs created
```

### Step 8: Align cron job models to main session (if user requests)
After recreating cron jobs, the user may want all jobs to use the same model/API as the main session. Batch-update all jobs:
```python
cronjob(action="update", job_id="<id>", model={"model": "<current_model>", "provider": "<current_provider>"})
```
Do this in one turn with all job IDs. Confirm with `cronjob(action="list")`.

### Step 9: Test all scripts
After restore, verify every script runs without errors:
```bash
python3 ~/.hermes/task_manager/scripts/task_manager.py list
python3 ~/.hermes/weight_tracker/scripts/weight_tracker.py progress
python3 ~/.hermes/calorie_tracker/scripts/calorie_tracker.py status
python3 ~/.hermes/news_feed/scripts/news_feed.py stats
```
Create any missing scripts (e.g., news_feed.py) if the backup references them but doesn't include them.

### Step 10: Configure backup script
The backup_hermes.sh script may have a stale/redacted PAT. Update it:
```bash
sed -i 's/ACCESS_TOKEN=".*"/ACCESS_TOKEN="<PAT>"/' ~/.hermes/scripts/backup_hermes.sh
```

## Backup Script Maintenance

When the backup cron job fails, fix the script at `~/.hermes/scripts/backup_hermes.sh`:

### Common bugs

1. **tar timestamp mismatch** — If `BACKUP_DIR` uses `$(date ...)` and a later command like `tar` uses a *separate* date call, the timestamps differ and tar fails with `Cannot stat`. Fix: store the stamp once in a variable and reuse it everywhere in the script.

2. **Git clone URLs must use the shell variable** — The clone/push URLs should reference `$ACCESS_TOKEN`, not a literal placeholder or hardcoded token. Verify raw bytes with `od -c` if terminal output appears to redact values.

3. **Script recovery from backup tarballs** — If the script is corrupted or credentials are lost, recover it from the GitHub repo: clone the backup repo, extract the latest tarball, and the script is at `scripts/backup_hermes.sh` inside the extracted directory.

### Token redaction pitfall (CRITICAL)

The `read_file` tool auto-redacts credentials (PATs, tokens). If you use the redacted output in a `patch` or `write_file` call, you **overwrite the real token with the redacted placeholder** and the token is lost from that file.

Prevention:
- Edit files containing tokens using `terminal` plus `sed`/`python`, NOT `read_file` then `patch`.
- After any edit to a file with tokens, verify the real bytes with `od -c` on the relevant line.
- If a token is already lost, recover it from the latest backup tarball in the GitHub repo (see step 10).

## Pitfalls

1. **Tracker scripts location (CRITICAL)** — In backups, Python trackers (task_manager, weight_tracker, calorie_tracker) are often nested under `skills/*/scripts/` rather than `scripts/`. Always `find` them before copying.

2. **HTTPS not SSH** — Cloud servers often have port 22 closed. Use `https://<PAT>@github.com/...` for git operations.

3. **Security: PAT in chat** — When user shares a GitHub PAT in chat, warn them to revoke/regenerate after the operation.

4. **Script paths in cron jobs** — Cron job scripts are referenced by filename only (relative to `~/.hermes/scripts/`). After copying scripts, ensure filenames match what the cron job expects.

5. **Cron job model/provider** — The backup JSON includes the model and provider. Use them exactly — don't guess or substitute. If the provider is `openai-api` with a custom model name (e.g., `mycombo`), preserve that.

6. **Telegram delivery targets** — Group chat IDs (large numbers like -1004281458610) and personal chat IDs are in the backup. Match them exactly when recreating delivery targets.

7. **Timezone conversion** — Cron schedules in the backup are in UTC. When explaining to the user, convert to their timezone (e.g., Tehran = UTC+3:30). Do NOT change the actual cron expressions.

8. **Custom skills not auto-restored** — The backup may contain custom skill directories (under `skills/`). These are NOT automatically restored by copying files — they need `skill_manage(action='create')` to register properly. Prioritize restoring user-facing operational skills (trading journal, financial market intel, cron automation patterns) over reference/documentation skills.

9. **Referenced scripts may not exist in backup** — Cron job prompts may reference scripts (e.g., `news_feed.py`) that are mentioned in SKILL.md documentation but not actually included in the backup archive. If a script is missing, create it based on the SKILL.md description and data patterns found in the backup's skill references.

10. **Forex Factory scraping** — The Forex Factory news page (`forexfactory.com/news`) returns HTTP 403 for scraping. The calendar API (`nfs.faireconomy.media/ff_calendar_thisweek.json`) works reliably. Design news scripts to use the calendar API as primary source.

11. **Model migration after restore** — The backup may reference a model name (e.g., `mycombo`) that's specific to a previous provider setup. After restore, the user often wants to align all cron jobs to the current main session's model. Ask proactively or do it when they say "use the same API as me."

12. **read_file redaction destroys tokens** — When `read_file` outputs a file containing PATs/tokens, the values are redacted. If you then `patch` or `write_file` using that redacted text, the real token is replaced with the placeholder. Always edit credential-bearing files via `terminal` with `sed`/`python`, and verify with `od -c` afterward.
