---
name: financial-market-intel
description: "Financial data collection, event monitoring, and delivery."
version: 1.0.0
created_by: agent
---

# Financial Market Intelligence

## Use When
- User wants scheduled economic news/calendar updates
- User wants financial data summarized from Forex Factory
- User wants market intel delivered to Telegram on a recurring basis
- User wants real-time notifications when economic events are released
- User wants market impact analysis comparing actual vs forecast results

## Data Sources

### Forex Factory Economic Calendar
**API:** `https://nfs.faireconomy.media/ff_calendar_thisweek.json`

**Data Structure:**
```json
{
  "title": "CPI m/m",
  "currency": "USD",
  "impact": "High",
  "date": "2026-07-28T21:30:00-04:00",
  "forecast": "0.2%",
  "previous": "-0.7%"
}
```

**Filtering:** Focus on `impact: "High"` and `impact: "Medium"` events.

## Critical Pitfalls

### 1. ONLY Show UPCOMING Events (CRITICAL)
The calendar API returns ALL events for the week, including past ones. Sending past events to users causes confusion and loss of credibility.

**User Correction:** "CPI نداریم دوشنبه که" — User's friend correctly pointed out that CPI was last week, not this week.

**Fix:** Filter events to only include future events:
```python
now = datetime.now(timezone.utc)
for event in data:
    event_date = datetime.fromisoformat(event['date'].replace('Z', '+00:00'))
    if event_date < (now - timedelta(hours=2)):
        continue  # Skip past events
```

### 2. API Rate Limiting
Forex Factory API returns 429 after ~10 requests/hour. Scripts must implement caching.

**Fix:** Store fetched data in JSON cache, serve from cache on failure.

### 3. Data Accuracy Verification
Before sending financial data to groups, verify:
- Event dates are in the future
- Forecast/previous values are present
- Currency codes are correct
- Impact levels are accurate

### 5. Economic Event Monitor: Published vs Upcoming (CRITICAL)
The calendar API returns events with both past and future dates. The cron prompt must NOT say an event is "published" AND "awaiting publication" simultaneously.

**User Correction:** "چجوری میشه هم منتشر شده و هم در انتظار انتشار باشه؟"

**Fix:** Check the `actual` field to determine status:
```
if event has actual value → event is PUBLISHED, show result
if event has NO actual value → event is UPCOMING, show forecast only
NEVER mix both statuses for the same event
```

**Correct prompt pattern:**
```
Check if "actual" field has a value:
- If YES: event is published, analyze the result vs forecast
- If NO: event is upcoming, just mention briefly
- NEVER say an event is both published and awaiting
```

### 4. News Feed Deduplication Causes Silent Delivery (CRITICAL)
When the news feed script caches stories, re-running it returns `new: 0` because all stories are already cached. The cron prompt then responds with `[SILENT]` — even when the user explicitly asks to see the data.

**Symptom:** User says "send this to the group" but nothing arrives because the script reports no new stories.

**Fix:** Before re-running, clear the cache:
```bash
rm -f /data/.hermes/news_feed/news.json
python3 news_feed.py fetch
```

**Better fix:** Modify the cron prompt to distinguish between "no upcoming events" and "no new events since last fetch":
```
If output shows upcoming events (count > 0), format and send.
If output shows 0 upcoming events, respond [SILENT].
Do NOT treat "0 new" as "nothing to report" — check for upcoming events.
```

## Summarization Formats

### Persian (Farsi) — Preferred for Text
```markdown
## اخبار اقتصادی هفته [date]

### [Day Name] [Date]

**[Event Name]** - [Currency]
- اهمیت: [High/Medium]
- پیش‌بینی: [Forecast]
- قبل: [Previous]
- اگر بیشتر باشد: [brief impact]
- اگر کمتر باشد: [brief impact]
```

### English — Preferred for Voice
Keep voice summaries concise (120 words max), conversational tone.

## Market Impact Analysis

| Event Type | Actual > Forecast | Actual < Forecast |
|------------|-------------------|-------------------|
| CPI/Inflation | Dollar ↑ | Dollar ↓ |
| NFP/Employment | Dollar ↑ | Dollar ↓ |
| GDP | Dollar ↑, Stocks ↑ | Dollar ↓ |
| Rate Decision | Dollar ↑↑ | Dollar ↓↓, Gold ↑ |

## Cron Job Setup

### Weekly Summary Job
```python
cronjob(
    action="create",
    schedule="30 17 * * 0",  # Sunday 9:30pm Tehran
    prompt="Write economic summary in PERSIAN...",
    script="forex_factory_news.py",
    deliver="origin,telegram:<group_id>"
)
```

### Real-time Monitor Job
```python
cronjob(
    action="create",
    schedule="every 120m",
    prompt="Check for economic events...",
    script="forex_event_monitor.py",
    deliver="origin,telegram:<group_id>"
)
```

## Reference Files
- `references/telegram-group-delivery.md` — Group delivery patterns
- `scripts/forex_factory_news.py` — Calendar fetcher with caching
- `scripts/forex_event_monitor.py` — Real-time event monitor
