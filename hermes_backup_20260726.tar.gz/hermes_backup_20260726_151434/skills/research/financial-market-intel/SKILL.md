---
name: financial-market-intel
description: "Scheduled financial data collection and market summaries."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [finance, economic-calendar, forex, cron, summarization]
---

# Financial Market Intelligence

Collect, analyze, and deliver financial/economic data on a schedule. Covers API data collection, cron job setup, and multilingual summarization for traders and investors.

## Use When

- User wants scheduled economic news/calendar updates
- User wants financial data summarized from sources like Forex Factory
- User wants market intel delivered to Telegram/Discord/etc on a recurring basis
- User provides an example format for financial summaries

## Data Sources

### Forex Factory Economic Calendar

**API Endpoint:** `https://nfs.faireconomy.media/ff_calendar_thisweek.json`

**Data Structure:**
```json
{
  "title": "CPI m/m",
  "currency": "USD",
  "impact": "High",  // High, Medium, Low
  "date": "2026-07-28T21:30:00-04:00",
  "forecast": "0.2%",
  "previous": "-0.7%"
}
```

**Filtering:** Focus on `impact: "High"` and `impact: "Medium"` events for actionable summaries.

**Currency Codes:** USD, EUR, GBP, JPY, CHF, CAD, AUD, NZD, CNY

## Cron Job Setup

### Critical Pitfalls

1. **Model must be configured** — Cron jobs fail with `RuntimeError: has no model configured`. Always set model via `cronjob action=update job_id=... model=<name>`.

2. **Provider name matters** — Use the exact provider name from your config. Common mistake: `"openai"` fails; correct is `"openai-api"` (check with `hermes model`).

3. **Script paths must be relative** — Scripts live in `~/.hermes/scripts/`. Use filename only: `script: "forex_factory_news.py"`, NOT absolute path.

### Setup Pattern

```python
# 1. Create data collection script at ~/.hermes/scripts/<name>.py
# 2. Create cron job
cronjob(action="create", 
        schedule="0 9 * * 0",  # Every Sunday 9am
        prompt="...",
        script="<name>.py",  # Relative path
        deliver="telegram")
# 3. Configure model
cronjob(action="update", job_id="<id>", model={"model": "gpt-4o", "provider": "openai-api"})
```

## Summarization Format (Persian/Farsi)

### Structure

```markdown
## 📊 خلاصه اخبار اقتصادی هفته [tarikh]

### رویدادهای مهم:
#### [روز] [تاریخ]
- [نام رویداد] - [واحد پول]
  - اهمیت: 🔴 مهم / 🟡 متوسط
  - پیش‌بینی: [مقدار]
  - قبلی: [مقدار]
  - توضیح: [اهمیت رویداد]

### تحلیل و پیش‌بینی:
- تأثیر بر بازارهای مالی
- جفت‌ارزهای کلیدی (EURUSD, GBPUSD, USDJPY)
- تأثیر بر طلا و نفت

### نکات کلیدی:
- مهم‌ترین رویدادها
- ریسک‌ها و فرصت‌ها
```

### Style Guidelines

- Use emojis for visual hierarchy (🔴🟡🟢 for importance)
- Include currency flag emojis (🇺🇸🇪🇺🇬🇧🇯🇵)
- Professional, analytical tone
- Group events by date
- Highlight key implications for traders

## Example: FOMC Summary Pattern

When summarizing FOMC or central bank decisions:

1. **Decision:** Rate unchanged/changed, vote count
2. **Key Points:** Inflation outlook, economic strength, labor market
3. **Forward Guidance:** Future rate expectations, data dependence
4. **Market Impact:** Dollar, bonds, equities, commodities
5. **Trading Implications:** Specific pairs and assets to watch

## Scripts

- `scripts/forex_factory_fetcher.py` — Ready-to-use script for fetching Forex Factory data. Copy to `~/.hermes/scripts/` and use as cron job script.

## Related Skills

- `blogwatcher` — RSS/feed monitoring (different data source pattern)
- `polymarket` — Prediction market data
