#!/usr/bin/env python3
"""
Real-time Economic Event Monitor for Forex Factory
Checks for events happening now or recently released.
Output is injected into agent prompt as context.
"""
import urllib.request
import json
from datetime import datetime

def fetch_forex_factory():
    """Fetch economic calendar from Forex Factory JSON API."""
    url = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
    })
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            return json.loads(response.read().decode('utf-8'))
    except Exception as e:
        return {"error": str(e)}

def format_currency(currency):
    """Map currency codes to Persian names with flags."""
    currencies = {
        "USD": "🇺🇸 دلار آمریکا",
        "EUR": "🇪🇺 یورو",
        "GBP": "🇬🇧 پوند انگلیس",
        "JPY": "🇯🇵 ین ژاپن",
        "CHF": "🇨🇭 فرانک سوئیس",
        "CAD": "🇨🇦 دلار کانادا",
        "AUD": "🇦🇺 دلار استرالیا",
        "NZD": "🇳🇿 دلار نیوزیلند",
        "CNY": "🇨🇳 یوان چین",
    }
    return currencies.get(currency, currency)

def get_market_impact(event_title, actual, forecast, previous):
    """Generate market impact analysis based on event type and results."""
    try:
        actual_val = float(actual.replace('%', '').replace('K', '000').replace('M', '000000')) if actual else None
        forecast_val = float(forecast.replace('%', '').replace('K', '000').replace('M', '000000')) if forecast else None
    except:
        return "داده کافی برای تحلیل وجود ندارد"
    
    if actual_val is None or forecast_val is None:
        return "داده کافی برای تحلیل وجود ندارد"
    
    is_better = actual_val > forecast_val
    is_worse = actual_val < forecast_val
    event_lower = event_title.lower()
    
    if 'cpi' in event_lower or 'inflation' in event_lower:
        if is_worse:
            return "تورم کمتر از انتظار → احتمال کاهش نرخ بهره ↑ → دلار ↓"
        elif is_better:
            return "تورم بیشتر از انتظار → احتمال افزایش نرخ بهره ↑ → دلار ↑"
        else:
            return "تورم مطابق انتظار → تأثیر خنثی بر بازار"
    elif 'nfp' in event_lower or 'non-farm' in event_lower or 'employment' in event_lower:
        if is_better:
            return "اشتغال بهتر از انتظار → اقتصاد قوی → دلار ↑"
        elif is_worse:
            return "اشتغال ضعیف‌تر → احتمال کاهش نرخ بهره → دلار ↓"
        else:
            return "اشتغال مطابق انتظار → تأثیر محدود"
    elif 'gdp' in event_lower:
        if is_better:
            return "رشد اقتصادی قوی → دلار ↑ → بورس ↑"
        elif is_worse:
            return "رشد اقتصادی ضعیف → دلار ↓ → نگرانی رکود"
        else:
            return "رشد مطابق انتظار → تأثیر خنثی"
    elif 'interest rate' in event_lower or 'rate decision' in event_lower:
        if actual_val > (float(previous.replace('%', '')) if previous else 0):
            return "افزایش نرخ بهره → دلار ↑↑ → طلا ↓"
        elif actual_val < (float(previous.replace('%', '')) if previous else 0):
            return "کاهش نرخ بهره → دلار ↓↓ → طلا ↑"
        else:
            return "نرخ بهره ثابت → تأثیر محدود"
    else:
        if is_better:
            return f"داده بهتر از انتظار ({actual} vs {forecast}) → تأثیر مثبت بر ارز مربوطه"
        elif is_worse:
            return f"داده ضعیف‌تر از انتظار ({actual} vs {forecast}) → تأثیر منفی بر ارز مربوطه"
        else:
            return f"داده مطابق انتظار ({actual} = {forecast}) → تأثیر خنثی"

def check_events():
    """Check for events happening now or in the next hour."""
    data = fetch_forex_factory()
    
    if "error" in data:
        print(json.dumps({"error": data["error"]}, ensure_ascii=False))
        return
    
    now = datetime.now()
    upcoming_events = []
    recent_events = []
    
    for event in data:
        importance = event.get('impact', '')
        if importance not in ['High', 'Medium']:
            continue
            
        title = event.get('title', '')
        currency = event.get('currency', '')
        date_str = event.get('date', '')
        forecast = event.get('forecast', '')
        previous = event.get('previous', '')
        actual = event.get('actual', '')
        
        try:
            event_time = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
            event_time_naive = event_time.replace(tzinfo=None)
            time_diff = (event_time_naive - now).total_seconds() / 60
            
            event_info = {
                'title': title,
                'currency': format_currency(currency),
                'importance': importance,
                'time': event_time.strftime('%H:%M'),
                'forecast': forecast,
                'previous': previous,
                'actual': actual,
                'minutes_until': int(time_diff)
            }
            
            if 0 <= time_diff <= 30:
                event_info['status'] = 'publishing_now'
                upcoming_events.append(event_info)
            elif -30 <= time_diff < 0:
                event_info['status'] = 'just_released'
                if actual:
                    event_info['impact_analysis'] = get_market_impact(title, actual, forecast, previous)
                recent_events.append(event_info)
            elif 30 < time_diff <= 60:
                event_info['status'] = f'upcoming_in_{int(time_diff)}_min'
                upcoming_events.append(event_info)
                
        except:
            continue
    
    result = {
        'check_time': now.strftime('%Y-%m-%d %H:%M'),
        'has_notifications': len(upcoming_events) > 0 or len(recent_events) > 0,
        'upcoming_events': upcoming_events,
        'recent_events': recent_events
    }
    
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    check_events()
