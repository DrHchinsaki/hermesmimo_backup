#!/usr/bin/env python3
"""
Fetch economic calendar data from Forex Factory for the upcoming week.
Outputs structured JSON that the agent can summarize in any language.

API: https://nfs.faireconomy.media/ff_calendar_thisweek.json
"""
import urllib.request
import json
from datetime import datetime

def fetch_forex_factory():
    """Fetch economic calendar from Forex Factory JSON API."""
    url = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
    
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
    })
    
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            data = json.loads(response.read().decode('utf-8'))
            return data
    except Exception as e:
        return {"error": str(e)}

def format_importance(impact):
    """Convert impact level to Persian."""
    mapping = {
        "High": "🔴 مهم",
        "Medium": "🟡 متوسط", 
        "Low": "🟢 کم‌اهمیت"
    }
    return mapping.get(impact, impact)

def format_currency(currency):
    """Map currency codes to Persian names with flags."""
    currencies = {
        "USD": "🇺🇸 دلار آمریکا",
        "EUR": "🇪🇺 یورو",
        "GBP": "🇬🇧 پوند انگلیس",
        "JPY": "🇯🇵 ین ژاپن",
        "CHF": "🇨🇭 فرانک سوئیس",
        "CAD": "🇨🇦 دلار کانادا",
        "AUD": "🇦🇺 دلار استرالیا",
        "NZD": "🇳🇿 دلار نیوزیلند",
        "CNY": "🇨🇳 یوان چین",
    }
    return currencies.get(currency, currency)

def main():
    data = fetch_forex_factory()
    
    if "error" in data:
        print(json.dumps({"error": data["error"]}, ensure_ascii=False))
        return
    
    # Filter for high and medium importance events
    important_events = []
    
    for event in data:
        importance = event.get('impact', '')
        title = event.get('title', '')
        currency = event.get('currency', '')
        date = event.get('date', '')
        forecast = event.get('forecast', '')
        previous = event.get('previous', '')
        
        event_info = {
            'title': title,
            'currency': format_currency(currency),
            'currency_code': currency,
            'importance': format_importance(importance),
            'date': date,
            'forecast': forecast,
            'previous': previous
        }
        
        if importance in ['High', 'Medium']:
            important_events.append(event_info)
    
    # Group by date
    events_by_date = {}
    day_name_persian = {
        0: 'دوشنبه', 1: 'سه‌شنبه', 2: 'چهارشنبه',
        3: 'پنج‌شنبه', 4: 'جمعه', 5: 'شنبه', 6: 'یکشنبه'
    }
    
    for event in important_events:
        try:
            dt = datetime.fromisoformat(event['date'].replace('Z', '+00:00'))
            date_key = dt.strftime('%Y-%m-%d')
            day_name = day_name_persian.get(dt.weekday(), '')
            date_display = f"{day_name} {dt.strftime('%d/%m')}"
        except:
            date_display = event['date']
        
        if date_display not in events_by_date:
            events_by_date[date_display] = []
        events_by_date[date_display].append(event)
    
    # Output structured data
    output = {
        "week_start": datetime.now().strftime('%Y-%m-%d'),
        "total_events": len(data),
        "important_events": len(important_events),
        "events_by_date": events_by_date
    }
    
    print(json.dumps(output, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
