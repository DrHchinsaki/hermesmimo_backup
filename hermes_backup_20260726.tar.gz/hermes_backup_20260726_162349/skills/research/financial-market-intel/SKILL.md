---
name: financial-market-intel
description: "Scheduled financial data collection, real-time event monitoring, and market impact analysis."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [finance, economic-calendar, forex, cron, summarization]
---

# Financial Market Intelligence

Collect, analyze, and deliver financial/economic data on a schedule. Covers API data collection, cron job setup, and multilingual summarization for traders and investors.

## Use When

- User wants scheduled economic news/calendar updates
- User wants financial data summarized from sources like Forex Factory
- User wants market intel delivered to Telegram/Discord/etc on a recurring basis
- User provides an example format for financial summaries
- User wants real-time notifications when economic events are released
- User wants market impact analysis comparing actual vs forecast results

## Data Sources

### Forex Factory Economic Calendar

**API Endpoint:** `https://nfs.faireconomy.media/ff_calendar_thisweek.json`

**Data Structure:**
```json
{
  "title": "CPI m/m",
  "currency": "USD",
  "impact": "High",  // High, Medium, Low
  "date": "2026-07-28T21:30:00-04:00",
  "forecast": "0.2%",
  "previous": "-0.7%"
}
```

**Filtering:** Focus on `impact: "High"` and `impact: "Medium"` events for actionable summaries.

**Currency Codes:** USD, EUR, GBP, JPY, CHF, CAD, AUD, NZD, CNY

## Cron Job Setup

### Critical Pitfalls

1. **Model must be configured** — Cron jobs fail with `RuntimeError: has no model configured`. Always set model via `cronjob action=update job_id=... model=<name>`.

2. **Provider name matters** — Use the exact provider name from your config. Common mistake: `"openai"` fails; correct is `"openai-api"` (check with `hermes model`).

3. **Script paths must be relative** — Scripts live in `~/.hermes/scripts/`. Use filename only: `script: "forex_factory_news.py"`, NOT absolute path.

### Setup Pattern

```python
# 1. Create data collection script at ~/.hermes/scripts/<name>.py
# 2. Create cron job
cronjob(action="create", 
        schedule="0 9 * * 0",  # Every Sunday 9am
        prompt="...",
        script="<name>.py",  # Relative path
        deliver="telegram")
# 3. Configure model
cronjob(action="update", job_id="<id>", model={"model": "gpt-4o", "provider": "openai-api"})
```

## Summarization Format (Persian/Farsi)

### Structure

```markdown
## 📊 خلاصه اخبار اقتصادی هفته [tarikh]

### رویدادهای مهم:
#### [روز] [تاریخ]
- [نام رویداد] - [واحد پول]
  - اهمیت: 🔴 مهم / 🟡 متوسط
  - پیش‌بینی: [مقدار]
  - قبلی: [مقدار]
  - توضیح: [اهمیت رویداد]

### تحلیل و پیش‌بینی:
- تأثیر بر بازارهای مالی
- جفت‌ارزهای کلیدی (EURUSD, GBPUSD, USDJPY)
- تأثیر بر طلا و نفت

### نکات کلیدی:
- مهم‌ترین رویدادها
- ریسک‌ها و فرصت‌ها
```

### Style Guidelines

- Use emojis for visual hierarchy (🔴🟡🟢 for importance)
- Include currency flag emojis (🇺🇸🇪🇺🇬🇧🇯🇵)
- Professional, analytical tone
- Group events by date
- Highlight key implications for traders

## Example: FOMC Summary Pattern

When summarizing FOMC or central bank decisions:

1. **Decision:** Rate unchanged/changed, vote count
2. **Key Points:** Inflation outlook, economic strength, labor market
3. **Forward Guidance:** Future rate expectations, data dependence
4. **Market Impact:** Dollar, bonds, equities, commodities
5. **Trading Implications:** Specific pairs and assets to watch

## Scripts

- `scripts/forex_factory_fetcher.py` — Ready-to-use script for fetching Forex Factory data. Copy to `~/.hermes/scripts/` and use as cron job script.

## Real-Time Event Monitoring

### Pattern: Weekly Summary + Hourly Monitor

Set up two coordinated cron jobs:
1. **Weekly job** (Sunday 9am) — previews the week's events with times
2. **Hourly job** — checks if any events are happening now or just released

### Hourly Monitor Script

```python
#!/usr/bin/env python3
"""Check for events happening now or recently released."""
import urllib.request
import json
from datetime import datetime

def fetch_forex_factory():
    url = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
    })
    with urllib.request.urlopen(req, timeout=30) as response:
        return json.loads(response.read().decode('utf-8'))

def check_events():
    data = fetch_forex_factory()
    now = datetime.now()
    upcoming = []  # happening in next 30 min
    recent = []    # happened in last 30 min
    
    for event in data:
        if event.get('impact') not in ['High', 'Medium']:
            continue
        try:
            event_time = datetime.fromisoformat(
                event['date'].replace('Z', '+00:00')
            ).replace(tzinfo=None)
            diff_min = (event_time - now).total_seconds() / 60
            
            info = {
                'title': event['title'],
                'currency': event['currency'],
                'forecast': event.get('forecast', ''),
                'previous': event.get('previous', ''),
                'actual': event.get('actual', ''),
            }
            
            if 0 <= diff_min <= 30:
                info['status'] = 'publishing_now'
                upcoming.append(info)
            elif -30 <= diff_min < 0:
                info['status'] = 'just_released'
                recent.append(info)
        except:
            continue
    
    print(json.dumps({
        'has_notifications': len(upcoming) > 0 or len(recent) > 0,
        'upcoming': upcoming,
        'recent': recent
    }, ensure_ascii=False))
```

**Cron setup:**
```python
cronjob(action="create",
        schedule="every 60m",
        prompt="Check for economic events. If recent_events exist, analyze results and market impact. If no events, reply with nothing.",
        script="forex_event_monitor.py",
        deliver="telegram")
```

### Market Impact Analysis Logic

When an event releases, compare actual vs forecast:

| Event Type | Actual > Forecast | Actual < Forecast |
|------------|-------------------|-------------------|
| CPI/Inflation | Dollar ↑ (rate hike fear) | Dollar ↓ (rate cut hope) |
| NFP/Employment | Dollar ↑ (strong economy) | Dollar ↓ (recession fear) |
| GDP | Dollar ↑, Stocks ↑ | Dollar ↓, recession fear |
| Rate Decision | Dollar ↑↑ | Dollar ↓↓, Gold ↑ |
| Unemployment | Dollar ↑ (low = good) | Dollar ↓ (high = bad) |

**Prompt for analysis:**
```
Analyze the released economic event:
- Event: [title]
- Actual: [actual] vs Forecast: [forecast]
- Previous: [previous]

Provide:
1. Better/worse than expected?
2. Impact on EURUSD, USDJPY, Gold, Oil
3. Trading implication
```

## Multi-Job Orchestration

When setting up coordinated jobs (weekly + hourly):

1. **Weekly job** previews events and their scheduled times
2. **Hourly job** monitors for releases in real-time
3. **Both deliver to same channel** (e.g., Telegram)
4. **Hourly job should be silent when no events** — use prompt like "If no events, reply nothing"

This avoids spam: hourly job only notifies when something actually happens.

## Voice Summaries

Add voice (TTS) summaries to financial news delivery for users who prefer audio.

### CRITICAL: Voice Language Preference

**Users almost always prefer ENGLISH voice summaries over Persian.** Persian TTS quality is significantly worse than English across all providers (Hermes built-in, Gemini, Edge, etc.).

**Pattern:**
- Text summary → Persian (full analysis, detailed)
- Voice summary → English (concise, 1-minute radio style)

This hybrid approach gives users the best of both worlds: readable Persian text + clear English audio.

### Hermes Built-in TTS

Use the `text_to_speech` tool directly in cron job prompts:

```
After writing the Persian text summary, create an ENGLISH voice version:
- Write a 1-minute script (max 120 words English)
- Conversational radio-news tone
- Cover only the 3-4 most important events
- Use text_to_speech tool to generate audio
- Include MEDIA: path in your response
```

**Voice summary structure (English):**
```
Hello! Here's your weekly economic summary for [date].
Key events this week: On [day], [event] with forecast of [value].
Market analysis: [brief 1-2 sentence impact].
Key takeaway: [main trading implication].
Good luck with your trades!
```

### Prompt Pattern for Cron Jobs

When setting up a weekly financial news job with voice:

```python
cronjob(
    action="update",
    job_id="<id>",
    prompt="""
[existing Persian text summary instructions...]

2. SECOND, write an ENGLISH voice summary (max 1 minute):
   - Conversational tone, like radio news briefing
   - Cover only the 3-4 most important events
   - Max 120 words English
   - Format: "Hello! Here's your weekly economic summary..."
   
3. THEN use text_to_speech tool to convert the ENGLISH summary to audio
"""
)
```

### Pitfall: Voice Length

English speech is ~130-150 words/minute. Keep voice scripts concise:
- ❌ Detailed analysis with numbers and percentages (too long)
- ✅ "CPI came in at 3.5%, above expectations. Dollar strengthening." (concise)

### Gemini TTS API (Experimental)

Google AI Studio provides TTS models (`gemini-2.5-flash-preview-tts`, `gemini-3.1-flash-tts-preview`) but:
- May return 403 Forbidden if API key lacks TTS permissions
- Requires `responseModalities: ["AUDIO"]` in generation config
- Built-in Hermes TTS is more reliable for production cron jobs

If user specifically requests Gemini TTS, test with a simple call first before committing to it.

## Model Selection for Financial Analysis

### User Preference: Complex Tasks = Best Models

Users typically consider economic/financial analysis as "complex work" and want the best available models for it. Set expectations during setup:

| Task Complexity | Recommended Model | Provider |
|-----------------|-------------------|----------|
| 📊 Economic analysis, market summaries | Best available (e.g. `gemini-2.5-pro`) | Gemini Pro |
| 🔔 Real-time event monitoring | Fast model (e.g. `gemini-2.5-flash`) | Gemini Pro |
| 💬 Simple alerts, notifications | Any capable model | Any |

**Pattern:** When user has a Pro/paid account for a provider, use the best models for complex analysis tasks. Use faster/cheaper models for routine monitoring.

### OpenRouter Free Tier Limitation

OpenRouter free accounts can ONLY use models tagged `:free`. Paid models will fail with authentication errors.

**Available free models (as of 2026):**
- `nvidia/nemotron-3-ultra-550b-a55b:free` — Best for long analysis (1M context)
- `nvidia/nemotron-3-super-120b-a12b:free` — Good for summaries (262K)
- `google/gemma-4-31b-it:free` — Good for code (262K)
- `openai/gpt-oss-20b:free` — General use (131K)

**Do NOT use on free tier:** `anthropic/claude-*`, `openai/gpt-4*`, any model without `:free` suffix.

## Related Skills

- `blogwatcher` — RSS/feed monitoring (different data source pattern)
- `polymarket` — Prediction market data
- `scheduled-automation` — General cron patterns and backup automation
