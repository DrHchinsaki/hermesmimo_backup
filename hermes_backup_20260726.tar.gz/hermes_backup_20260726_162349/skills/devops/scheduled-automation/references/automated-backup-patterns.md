# Automated Backup to GitHub Pattern

## Use Case
Periodically archive local data (memory, configs, skills) and push to a GitHub repo. Useful for disaster recovery, portability, and version history.

## Complete Script

```bash
#!/bin/bash
set -e

# Configuration
HERMES_HOME="${HERMES_HOME:-$HOME/.hermes}"
REPO_URL="https://${ACCESS_TOKEN}@github.com/owner/repo.git"
BACKUP_DIR="/tmp/hermes_backup_$(date +%Y%m%d_%H%M%S)"
BACKUP_FILE="hermes_backup_$(date +%Y%m%d).tar.gz"

echo "🔄 Starting Hermes backup..."

# Create temporary backup directory
mkdir -p "$BACKUP_DIR"

# 1. Copy files to backup dir
echo "📦 Backing up files..."
[ -d "$HERMES_HOME/memories" ] && cp -r "$HERMES_HOME/memories" "$BACKUP_DIR/memory"
[ -f "$HERMES_HOME/SOUL.md" ] && cp "$HERMES_HOME/SOUL.md" "$BACKUP_DIR/"
[ -f "$HERMES_HOME/config.yaml" ] && cp "$HERMES_HOME/config.yaml" "$BACKUP_DIR/"
[ -d "$HERMES_HOME/skills" ] && cp -r "$HERMES_HOME/skills" "$BACKUP_DIR/skills"
[ -f "$HERMES_HOME/cron/jobs.json" ] && mkdir -p "$BACKUP_DIR/cron" && cp "$HERMES_HOME/cron/jobs.json" "$BACKUP_DIR/cron/"
[ -d "$HERMES_HOME/scripts" ] && cp -r "$HERMES_HOME/scripts" "$BACKUP_DIR/scripts"

# 2. Create archive
echo "🗜️ Creating archive..."
cd /tmp
tar -czf "$BACKUP_FILE" -C /tmp "hermes_backup_$(date +%Y%m%d_%H%M%S)"

# 3. Configure git (REQUIRED for automated commits)
git config --global user.email "backup@agent"
git config --global user.name "Hermes Agent"

# 4. Clone, add, push
echo "📤 Pushing to GitHub..."
REPO_DIR="/tmp/hermesmimo_backup_repo"
rm -rf "$REPO_DIR"

git clone "$REPO_URL" "$REPO_DIR" 2>/dev/null || {
    echo "Creating new repo structure..."
    mkdir -p "$REPO_DIR"
    cd "$REPO_DIR"
    git init
    git remote add origin "$REPO_URL"
}

cd "$REPO_DIR"
cp "/tmp/$BACKUP_FILE" .

# Create README with backup info
cat > README.md << EOF
# Hermes Agent Backup

## Latest Backup
- **Date:** $(date '+%Y-%m-%d %H:%M:%S')
- **File:** $BACKUP_FILE

## Contents
- Memory (MEMORY.md)
- SOUL.md (Personality)
- Config (config.yaml)
- Skills
- Cron Jobs
- Scripts

## How to Restore
\`\`\`bash
tar -xzf $BACKUP_FILE
# Copy files back to ~/.hermes/
\`\`\`
EOF

git add .
git commit -m "Backup: $(date '+%Y-%m-%d %H:%M:%S')" --allow-empty
git push origin main 2>&1

# 5. Cleanup
echo "🧹 Cleaning up..."
rm -rf "$REPO_DIR" "$BACKUP_DIR" "/tmp/$BACKUP_FILE"

echo "✅ Backup completed successfully!"
```

## What to Backup

| Path | Contents | Priority |
|------|----------|----------|
| `memories/` | User memory, agent notes | Critical |
| `SOUL.md` | Agent personality | Critical |
| `config.yaml` | Configuration | High |
| `skills/` | All installed skills | High |
| `cron/jobs.json` | Scheduled jobs | Medium |
| `scripts/` | Custom scripts | Medium |
| `cron/output/` | Recent outputs (last 7 days) | Low |

## What NOT to Backup

- `.env` — Contains secrets/tokens
- `auth.json` — OAuth tokens
- `*.lock` — Lock files
- `sessions/` — Can be very large
- `logs/` — Transient, not valuable
- `*.db` — SQLite databases (corruption risk if copied while in use)

## Scheduling with Hermes Cron

```bash
# Create backup script at ~/.hermes/scripts/backup_hermes.sh
chmod +x ~/.hermes/scripts/backup_hermes.sh

# Schedule via Hermes cron
cronjob(action="create",
        schedule="0 10 */3 * *",  # Every 3 days at 10am
        prompt="Run backup script and report status",
        script="backup_hermes.sh",
        deliver="telegram")
```

## Critical Pitfalls

1. **Git identity required** — Automated commits fail with `Author identity unknown`. Always set `user.email` and `user.name`.

2. **HTTPS token in URL** — When SSH port 22 is closed, embed token: `https://${TOKEN}@github.com/owner/repo.git`

3. **Clean up temp dirs** — Always remove `/tmp` artifacts after push.

4. **Handle empty repos** — First push needs `git init` + `git remote add`, not `git clone`.
