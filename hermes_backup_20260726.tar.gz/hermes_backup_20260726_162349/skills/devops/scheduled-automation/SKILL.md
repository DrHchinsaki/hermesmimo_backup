---
name: scheduled-automation
description: "Cron jobs, backups, and recurring pipelines in Hermes."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [cron, automation, backup, scheduled-tasks, github, devops]
  related_skills: [financial-market-intel, github-repo-management, github-auth]
---

# Scheduled Automation

Patterns for recurring automated tasks in Hermes: cron jobs, data collection pipelines, and automated backups. Captures reusable patterns and pitfalls across automation use cases.

## Use When

- User wants something to run on a schedule (daily, weekly, every N days)
- User wants automated backups to GitHub or other remote storage
- User wants recurring data collection from APIs
- User wants reports delivered to Telegram/Discord on a schedule
- Setting up cron jobs with scripts that collect data

## Cron Job Setup Pattern

### Step 1: Create the Data Collection Script

Place scripts in `~/.hermes/scripts/` with a descriptive name:

```python
#!/usr/bin/env python3
"""Script to collect data. stdout is injected into agent prompt."""
import urllib.request
import json

def main():
    url = "https://api.example.com/data"
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    
    with urllib.request.urlopen(req, timeout=30) as response:
        data = json.loads(response.read().decode('utf-8'))
    
    print(json.dumps(data, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
```

### Step 2: Create the Cron Job

```python
cronjob(
    action="create",
    schedule="0 9 * * 0",      # Cron syntax or "every 3 days"
    prompt="Summarize the following data...",
    script="my_script.py",      # Relative to ~/.hermes/scripts/
    deliver="telegram",
    name="Descriptive Job Name"
)
```

### Step 3: Configure the Model

**Critical** — jobs fail without a model:

```python
cronjob(
    action="update",
    job_id="<id>",
    model={"model": "Hermes-mimo", "provider": "openai-api"}
)
```

## Critical Pitfalls

### 1. Model Not Configured
**Error:** `RuntimeError: Cron job has no model configured`
**Fix:** Always run `cronjob(action="update", job_id=..., model=...)` after creation.

### 2. Wrong Provider Name
**Error:** `RuntimeError: Unknown provider 'openai'`
**Fix:** Use exact provider name. Common: `"openai-api"` not `"openai"`. Check with `hermes model`.

### 3. Absolute Script Path
**Error:** `Script path must be relative to ~/.hermes/scripts/`
**Fix:** Use filename only: `script="my_script.py"`, NOT full path.

### 4. Git Identity Not Set
**Error:** `fatal: unable to auto-detect email address`
**Fix:** Configure before automated commits:
```bash
git config --global user.email "backup@agent"
git config --global user.name "Hermes Agent"
```

### 5. SSH Port Closed
**Error:** `ssh: connect to host github.com port 22: Connection refused`
**Fix:** Use HTTPS with token: `https://${TOKEN}@github.com/owner/repo.git`

## Automated Backup Pattern

For periodic backups to GitHub (see `references/automated-backup-patterns.md`):

```bash
#!/bin/bash
set -e
REPO_URL="https://${ACCESS_TOKEN}@github.com/owner/repo.git"
BACKUP_FILE="backup_$(date +%Y%m%d).tar.gz"

tar -czf "/tmp/$BACKUP_FILE" -C ~/.hermes \
    memories/ SOUL.md config.yaml skills/ scripts/ cron/jobs.json

git config --global user.email "backup@agent"
git config --global user.name "Hermes Agent"

REPO_DIR="/tmp/backup_repo"
rm -rf "$REPO_DIR"
git clone "$REPO_URL" "$REPO_DIR" 2>/dev/null || {
    mkdir -p "$REPO_DIR" && cd "$REPO_DIR" && git init
    git remote add origin "$REPO_URL"
}
cp "/tmp/$BACKUP_FILE" "$REPO_DIR/"
cd "$REPO_DIR"
git add . && git commit -m "Backup: $(date)" && git push origin main
rm -rf "$REPO_DIR" "/tmp/$BACKUP_FILE"
```

## Schedule Syntax Reference

| Format | Example | Meaning |
|--------|---------|---------|
| Duration | `"30m"`, `"2h"`, `"1d"` | Every N minutes/hours/days |
| Cron | `"0 9 * * *"` | Daily at 9am |
| Cron | `"0 9 * * 0"` | Every Sunday at 9am |
| Cron | `"0 10 */3 * *"` | Every 3 days at 10am |

## What to Backup (Hermes)

| Path | Contents | Priority |
|------|----------|----------|
| `memories/` | User memory, agent notes | Critical |
| `SOUL.md` | Agent personality | Critical |
| `config.yaml` | Configuration | High |
| `skills/` | All installed skills | High |
| `cron/jobs.json` | Scheduled jobs | Medium |
| `scripts/` | Custom scripts | Medium |

**Never backup:** `.env`, `auth.json`, `*.lock`, `sessions/`, `logs/`, `*.db` (while in use)

## Model Selection Strategy

### Task Complexity → Model Mapping

Different tasks need different model tiers. Users often have mixed provider access (e.g., free OpenRouter + paid Gemini Pro).

| Task Type | Recommended Tier | Example |
|-----------|------------------|---------|
| 📊 Complex analysis (financial, research) | Best available | `gemini-2.5-pro` |
| 🔄 Routine monitoring (hourly checks) | Fast/cheap | `gemini-2.5-flash` |
| 💾 Simple operations (backups, alerts) | Any capable | `Hermes-mimo` |

### Provider Access Patterns

**Free tier (OpenRouter):**
- Only use models with `:free` suffix
- Best: `nvidia/nemotron-3-ultra-550b-a55b:free` (1M context)
- Good: `google/gemma-4-31b-it:free`, `openai/gpt-oss-20b:free`

**Paid tier (Gemini Pro):**
- All models available
- Complex tasks: `gemini-2.5-pro`
- Fast tasks: `gemini-2.5-flash`

**User preference:** When user says "this is complex work," assign the best model from their available providers.

## Related Skills

- `financial-market-intel` — Financial data collection (specific use case)
- `github-auth` — GitHub authentication setup
- `github-repo-management` — Repository operations
