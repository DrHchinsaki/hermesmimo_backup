#!/bin/bash
# Hermes Agent Backup Script
# Backs up memory, skills, config, and important files to GitHub
# Usage: bash backup_hermes.sh

set -e

# Configuration
HERMES_HOME="${HERMES_HOME:-$HOME/.hermes}"
BACKUP_DIR="/tmp/hermes_backup_$(date +%Y%m%d_%H%M%S)"
REPO_URL="https://${ACCESS_TOKEN}@github.com/owner/repo.git"
BACKUP_FILE="hermes_backup_$(date +%Y%m%d).tar.gz"

echo "🔄 Starting Hermes backup..."

# Create temporary backup directory
mkdir -p "$BACKUP_DIR"

# 1. Backup Memory
echo "📦 Backing up memory..."
[ -d "$HERMES_HOME/memories" ] && cp -r "$HERMES_HOME/memories" "$BACKUP_DIR/memory"

# 2. Backup SOUL.md (personality)
echo "👤 Backing up SOUL.md..."
[ -f "$HERMES_HOME/SOUL.md" ] && cp "$HERMES_HOME/SOUL.md" "$BACKUP_DIR/"

# 3. Backup Config
echo "⚙️ Backing up config..."
[ -f "$HERMES_HOME/config.yaml" ] && cp "$HERMES_HOME/config.yaml" "$BACKUP_DIR/"

# 4. Backup Skills
echo "🛠️ Backing up skills..."
[ -d "$HERMES_HOME/skills" ] && cp -r "$HERMES_HOME/skills" "$BACKUP_DIR/skills"

# 5. Backup Cron jobs
echo "⏰ Backing up cron jobs..."
if [ -f "$HERMES_HOME/cron/jobs.json" ]; then
    mkdir -p "$BACKUP_DIR/cron"
    cp "$HERMES_HOME/cron/jobs.json" "$BACKUP_DIR/cron/"
fi

# 6. Backup Scripts
echo "📜 Backing up scripts..."
[ -d "$HERMES_HOME/scripts" ] && cp -r "$HERMES_HOME/scripts" "$BACKUP_DIR/scripts"

# 7. Backup recent cron outputs (last 7 days)
echo "📋 Backing up recent cron outputs..."
if [ -d "$HERMES_HOME/cron/output" ]; then
    mkdir -p "$BACKUP_DIR/cron/output"
    find "$HERMES_HOME/cron/output" -name "*.md" -mtime -7 -exec cp {} "$BACKUP_DIR/cron/output/" \; 2>/dev/null || true
fi

# Create tar.gz archive
echo "🗜️ Creating archive..."
cd /tmp
tar -czf "$BACKUP_FILE" -C /tmp "hermes_backup_$(date +%Y%m%d_%H%M%S)"

# Configure git (REQUIRED for automated commits)
git config --global user.email "backup@agent"
git config --global user.name "Hermes Agent"

# Clone repo, add backup, and push
echo "📤 Pushing to GitHub..."
REPO_DIR="/tmp/hermesmimo_backup_repo"

# Clean up if exists
rm -rf "$REPO_DIR"

# Clone the repo (handle first-time setup)
git clone "$REPO_URL" "$REPO_DIR" 2>/dev/null || {
    echo "Creating new repo structure..."
    mkdir -p "$REPO_DIR"
    cd "$REPO_DIR"
    git init
    git remote add origin "$REPO_URL"
}

cd "$REPO_DIR"

# Copy backup file
cp "/tmp/$BACKUP_FILE" .

# Create a README with backup info
cat > README.md << EOF
# Hermes Agent Backup

## Latest Backup
- **Date:** $(date '+%Y-%m-%d %H:%M:%S')
- **File:** $BACKUP_FILE

## Contents
- Memory (MEMORY.md)
- SOUL.md (Personality)
- Config (config.yaml)
- Skills
- Cron Jobs
- Scripts
- Recent Cron Outputs

## How to Restore
\`\`\`bash
tar -xzf $BACKUP_FILE
# Copy files back to ~/.hermes/
\`\`\`
EOF

# Git operations
git add .
git commit -m "Backup: $(date '+%Y-%m-%d %H:%M:%S')" --allow-empty
git push origin main 2>&1

# Cleanup
echo "🧹 Cleaning up..."
rm -rf "$REPO_DIR"
rm -rf "$BACKUP_DIR"
rm -f "/tmp/$BACKUP_FILE"

echo "✅ Backup completed successfully!"
echo "📁 Backup saved to: $REPO_URL"
