Cron job setup pitfalls: (1) Model must be configured or job fails with RuntimeError. (2) Provider name is "openai-api" not "openai" for OpenAI. (3) Script paths must be relative to ~/.hermes/scripts/, not absolute. Forex Factory API: https://nfs.faireconomy.media/ff_calendar_thisweek.json
§
TTS Preference: User prefers English voice summaries over Persian. Persian TTS quality is poor; English sounds much better. Keep voice summaries in English even when text is in Persian.
§
Active cron jobs: 1) Weekly Forex Factory economic news (Sundays 9am, Persian text + English voice), 2) Real-time economic event monitor (hourly), 3) Auto backup to GitHub every 3 days. User's GitHub backup repo: DrHchinsaki/hermesmimo_backup.
§
Environment: Port 22 is closed on this server. Use HTTPS for git operations instead of SSH.