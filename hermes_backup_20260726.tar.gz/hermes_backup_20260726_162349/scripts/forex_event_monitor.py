#!/usr/bin/env python3
"""
Economic Event Monitor for Forex Factory
Checks for upcoming or recently released economic events
and fetches actual results when available.
"""
import urllib.request
import json
from datetime import datetime, timedelta

def fetch_forex_factory():
    """Fetch economic calendar from Forex Factory JSON API."""
    url = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
    
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
    })
    
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            data = json.loads(response.read().decode('utf-8'))
            return data
    except Exception as e:
        return {"error": str(e)}

def format_importance(impact):
    """Convert impact level to Persian."""
    mapping = {
        "High": "🔴 مهم",
        "Medium": "🟡 متوسط", 
        "Low": "🟢 کم‌اهمیت"
    }
    return mapping.get(impact, impact)

def format_currency(currency):
    """Map currency codes to Persian names."""
    currencies = {
        "USD": "🇺🇸 دلار آمریکا",
        "EUR": "🇪🇺 یورو",
        "GBP": "🇬🇧 پوند انگلیس",
        "JPY": "🇯🇵 ین ژاپن",
        "CHF": "🇨🇭 فرانک سوئیس",
        "CAD": "🇨🇦 دلار کانادا",
        "AUD": "🇦🇺 دلار استرالیا",
        "NZD": "🇳🇿 دلار نیوزیلند",
        "CNY": "🇨🇳 یوان چین",
    }
    return currencies.get(currency, currency)

def get_market_impact(event_title, actual, forecast, previous):
    """Generate market impact analysis based on event type and results."""
    impact_analysis = ""
    
    # Parse values
    try:
        actual_val = float(actual.replace('%', '').replace('K', '000').replace('M', '000000')) if actual else None
        forecast_val = float(forecast.replace('%', '').replace('K', '000').replace('M', '000000')) if forecast else None
        previous_val = float(previous.replace('%', '').replace('K', '000').replace('M', '000000')) if previous else None
    except:
        return "تحلیل عددی امکان‌پذیر نیست"
    
    if actual_val is None or forecast_val is None:
        return "داده کافی برای تحلیل وجود ندارد"
    
    # Determine if result is better or worse than expected
    is_better = actual_val > forecast_val
    is_worse = actual_val < forecast_val
    is_same = actual_val == forecast_val
    
    # Event-specific analysis
    event_lower = event_title.lower()
    
    if 'cpi' in event_lower or 'inflation' in event_lower:
        if is_worse:
            impact_analysis = "تورم کمتر از انتظار → احتمال کاهش نرخ بهره ↑ → دلار ↓"
        elif is_better:
            impact_analysis = "تورم بیشتر از انتظار → احتمال افزایش نرخ بهره ↑ → دلار ↑"
        else:
            impact_analysis = "تورم مطابق انتظار → تأثیر خنثی بر بازار"
            
    elif 'nfp' in event_lower or 'non-farm' in event_lower or 'employment' in event_lower:
        if is_better:
            impact_analysis = "اشتغال بهتر از انتظار → اقتصاد قوی → دلار ↑"
        elif is_worse:
            impact_analysis = "اشتغال ضعیف‌تر → احتمال کاهش نرخ بهره → دلار ↓"
        else:
            impact_analysis = "اشتغال مطابق انتظار → تأثیر محدود"
            
    elif 'gdp' in event_lower:
        if is_better:
            impact_analysis = "رشد اقتصادی قوی → دلار ↑ → بورس ↑"
        elif is_worse:
            impact_analysis = "رشد اقتصادی ضعیف → دلار ↓ → نگرانی رکود"
        else:
            impact_analysis = "رشد مطابق انتظار → تأثیر خنثی"
            
    elif 'interest rate' in event_lower or 'rate decision' in event_lower:
        if actual_val > previous_val:
            impact_analysis = "افزایش نرخ بهره → دلار ↑↑ → طلا ↓"
        elif actual_val < previous_val:
            impact_analysis = "کاهش نرخ بهره → دلار ↓↓ → طلا ↑"
        else:
            impact_analysis = "نرخ بهره ثابت → تأثیر محدود"
            
    elif 'retail sales' in event_lower:
        if is_better:
            impact_analysis = "فروش خرده‌فروشی قوی → مصرف‌کننده سالم → دلار ↑"
        elif is_worse:
            impact_analysis = "فروش ضعیف → نگرانی اقتصادی → دلار ↓"
        else:
            impact_analysis = "فروش مطابق انتظار → تأثیر محدود"
            
    elif 'unemployment' in event_lower:
        if is_worse:
            impact_analysis = "بیکاری کمتر → بازار کار قوی → دلار ↑"
        elif is_better:
            impact_analysis = "بیکاری بیشتر → بازار کار ضعیف → دلار ↓"
        else:
            impact_analysis = "بیکاری مطابق انتظار → تأثیر خنثی"
    
    else:
        if is_better:
            impact_analysis = f"داده بهتر از انتظار ({actual} vs {forecast}) → تأثیر مثبت بر ارز مربوطه"
        elif is_worse:
            impact_analysis = f"داده ضعیف‌تر از انتظار ({actual} vs {forecast}) → تأثیر منفی بر ارز مربوطه"
        else:
            impact_analysis = f"داده مطابق انتظار ({actual} = {forecast}) → تأثیر خنثی"
    
    return impact_analysis

def check_events():
    """Check for events happening now or in the next hour."""
    data = fetch_forex_factory()
    
    if "error" in data:
        return json.dumps({"error": data["error"]}, ensure_ascii=False)
    
    now = datetime.now()
    upcoming_events = []
    recent_events = []
    
    for event in data:
        importance = event.get('impact', '')
        if importance not in ['High', 'Medium']:
            continue
            
        title = event.get('title', '')
        currency = event.get('currency', '')
        date_str = event.get('date', '')
        forecast = event.get('forecast', '')
        previous = event.get('previous', '')
        actual = event.get('actual', '')
        
        try:
            event_time = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
            # Remove timezone for comparison (simplified)
            event_time_naive = event_time.replace(tzinfo=None)
            
            time_diff = (event_time_naive - now).total_seconds() / 60  # minutes
            
            event_info = {
                'title': title,
                'currency': format_currency(currency),
                'currency_code': currency,
                'importance': format_importance(importance),
                'time': event_time.strftime('%H:%M'),
                'date': event_time.strftime('%Y-%m-%d'),
                'forecast': forecast,
                'previous': previous,
                'actual': actual,
                'minutes_until': int(time_diff)
            }
            
            # Event happening now or in next 30 minutes
            if 0 <= time_diff <= 30:
                event_info['status'] = '🔴 در حال انتشار!'
                upcoming_events.append(event_info)
            # Event happened in last 30 minutes
            elif -30 <= time_diff < 0:
                event_info['status'] = '✅ منتشر شد'
                if actual:
                    event_info['impact_analysis'] = get_market_impact(title, actual, forecast, previous)
                recent_events.append(event_info)
            # Event coming up in next hour
            elif 30 < time_diff <= 60:
                event_info['status'] = f'⏰ {int(time_diff)} دقیقه دیگر'
                upcoming_events.append(event_info)
                
        except Exception as e:
            continue
    
    result = {
        'check_time': now.strftime('%Y-%m-%d %H:%M'),
        'upcoming_events': upcoming_events,
        'recent_events': recent_events,
        'has_notifications': len(upcoming_events) > 0 or len(recent_events) > 0
    }
    
    return json.dumps(result, ensure_ascii=False, indent=2)

if __name__ == "__main__":
    print(check_events())
