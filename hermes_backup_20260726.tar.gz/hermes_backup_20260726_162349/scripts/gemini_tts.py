#!/usr/bin/env python3
"""
Text-to-Speech using Google Gemini API
Generates Persian voice summaries for economic news
"""
import urllib.request
import json
import base64
import os
from datetime import datetime

# Google AI Studio API Configuration
API_KEY = "AQ.Ab8RN6LzBCg_aOPoaAId9Zxyeygf7d4EB9qSh6gmV7Befebfxg"

def text_to_speech_gemini(text, output_path=None):
    """
    Convert text to speech using Gemini TTS API
    """
    if output_path is None:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_path = f"/data/.hermes/cache/audio/gemini_tts_{timestamp}.mp3"
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    # Use Gemini 2.5 Flash TTS model
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent?key={API_KEY}"
    
    # Request payload with TTS config
    payload = {
        "contents": [
            {
                "parts": [
                    {
                        "text": text
                    }
                ]
            }
        ],
        "generationConfig": {
            "responseModalities": ["AUDIO"],
            "speechConfig": {
                "voiceConfig": {
                    "prebuiltVoiceConfig": {
                        "voiceName": "Aoede"
                    }
                }
            }
        }
    }
    
    # Make API request
    data = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(url, data=data, headers={
        'Content-Type': 'application/json'
    })
    
    try:
        with urllib.request.urlopen(req, timeout=120) as response:
            result = json.loads(response.read().decode('utf-8'))
            
            # Extract audio data from response
            if 'candidates' in result and len(result['candidates']) > 0:
                candidate = result['candidates'][0]
                if 'content' in candidate and 'parts' in candidate['content']:
                    for part in candidate['content']['parts']:
                        if 'inlineData' in part:
                            audio_data = part['inlineData']['data']
                            audio_bytes = base64.b64decode(audio_data)
                            
                            with open(output_path, 'wb') as f:
                                f.write(audio_bytes)
                            
                            return {
                                'success': True,
                                'path': output_path,
                                'size': len(audio_bytes)
                            }
            
            return {
                'success': False,
                'error': 'No audio data in response',
                'response': result
            }
            
    except Exception as e:
        return {
            'success': False,
            'error': str(e)
        }

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        text = sys.argv[1]
        if os.path.isfile(text):
            with open(text, 'r', encoding='utf-8') as f:
                text = f.read()
    else:
        text = "سلام. این یک آزمایش تبدیل متن به گفتار با استفاده از Gemini API است."
    
    print(f"Generating TTS for text ({len(text)} chars)...")
    result = text_to_speech_gemini(text)
    
    if result['success']:
        print(f"SUCCESS: {result['path']}")
        print(f"Size: {result['size']} bytes")
    else:
        print(f"ERROR: {result['error']}")
        if 'response' in result:
            print(json.dumps(result['response'], indent=2, ensure_ascii=False))
