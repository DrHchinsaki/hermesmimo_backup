#!/bin/bash
# Hermes Agent Backup Script
# Backs up memory, skills, config, and important files to GitHub

set -e

# Configuration
HERMES_HOME="/data/.hermes"
BACKUP_DIR="/tmp/hermes_backup_$(date +%Y%m%d_%H%M%S)"
REPO_URL="https://github.com/DrHchinsaki/hermesmimo_backup.git"
ACCESS_TOKEN="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"
BACKUP_FILE="hermes_backup_$(date +%Y%m%d).tar.gz"

echo "🔄 Starting Hermes backup..."

# Create temporary backup directory
mkdir -p "$BACKUP_DIR"

# 1. Backup Memory
echo "📦 Backing up memory..."
if [ -d "$HERMES_HOME/memories" ]; then
    cp -r "$HERMES_HOME/memories" "$BACKUP_DIR/memory"
fi

# 2. Backup SOUL.md (personality)
echo "👤 Backing up SOUL.md..."
if [ -f "$HERMES_HOME/SOUL.md" ]; then
    cp "$HERMES_HOME/SOUL.md" "$BACKUP_DIR/"
fi

# 3. Backup Config
echo "⚙️ Backing up config..."
if [ -f "$HERMES_HOME/config.yaml" ]; then
    cp "$HERMES_HOME/config.yaml" "$BACKUP_DIR/"
fi

# 4. Backup Skills
echo "🛠️ Backing up skills..."
if [ -d "$HERMES_HOME/skills" ]; then
    cp -r "$HERMES_HOME/skills" "$BACKUP_DIR/skills"
fi

# 5. Backup Cron jobs
echo "⏰ Backing up cron jobs..."
if [ -f "$HERMES_HOME/cron/jobs.json" ]; then
    mkdir -p "$BACKUP_DIR/cron"
    cp "$HERMES_HOME/cron/jobs.json" "$BACKUP_DIR/cron/"
fi

# 6. Backup Scripts
echo "📜 Backing up scripts..."
if [ -d "$HERMES_HOME/scripts" ]; then
    cp -r "$HERMES_HOME/scripts" "$BACKUP_DIR/scripts"
fi

# 7. Backup recent cron outputs (last 7 days)
echo "📋 Backing up recent cron outputs..."
if [ -d "$HERMES_HOME/cron/output" ]; then
    mkdir -p "$BACKUP_DIR/cron/output"
    find "$HERMES_HOME/cron/output" -name "*.md" -mtime -7 -exec cp {} "$BACKUP_DIR/cron/output/" \; 2>/dev/null || true
fi

# Create tar.gz archive
echo "🗜️ Creating archive..."
cd /tmp
tar -czf "$BACKUP_FILE" -C /tmp "hermes_backup_$(date +%Y%m%d_%H%M%S)"

# Configure git
git config --global user.email "hermes-agent@backup"
git config --global user.name "Hermes Agent"

# Clone repo, add backup, and push
echo "📤 Pushing to GitHub..."
REPO_DIR="/tmp/hermesmimo_backup_repo"

# Clean up if exists
rm -rf "$REPO_DIR"

# Clone the repo
git clone "https://${ACCESS_TOKEN}@github.com/DrHchinsaki/hermesmimo_backup.git" "$REPO_DIR" 2>/dev/null || {
    echo "Creating new repo structure..."
    mkdir -p "$REPO_DIR"
    cd "$REPO_DIR"
    git init
    git remote add origin "https://${ACCESS_TOKEN}@github.com/DrHchinsaki/hermesmimo_backup.git"
}

cd "$REPO_DIR"

# Copy backup file
cp "/tmp/$BACKUP_FILE" .

# Create a README with backup info
cat > README.md << EOF
# Hermes Agent Backup

## Latest Backup
- **Date:** $(date '+%Y-%m-%d %H:%M:%S')
- **File:** $BACKUP_FILE

## Contents
- Memory (MEMORY.md)
- SOUL.md (Personality)
- Config (config.yaml)
- Skills
- Cron Jobs
- Scripts
- Recent Cron Outputs

## How to Restore
\`\`\`bash
tar -xzf $BACKUP_FILE
# Copy files back to ~/.hermes/
\`\`\`
EOF

# Git operations
git add .
git commit -m "Backup: $(date '+%Y-%m-%d %H:%M:%S')" --allow-empty
git push origin main 2>&1

# Cleanup
echo "🧹 Cleaning up..."
rm -rf "$REPO_DIR"
rm -rf "$BACKUP_DIR"
rm -f "/tmp/$BACKUP_FILE"

echo "✅ Backup completed successfully!"
echo "📁 Backup saved to: https://github.com/DrHchinsaki/hermesmimo_backup"
