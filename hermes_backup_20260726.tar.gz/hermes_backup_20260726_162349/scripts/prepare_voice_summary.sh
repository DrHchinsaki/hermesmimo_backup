#!/bin/bash
# Generate voice summary for economic news using Hermes TTS
# This script is called by the cron job

TEXT_FILE="/tmp/economic_summary_text.txt"
OUTPUT_FILE="/data/.hermes/cache/audio/economic_summary_$(date +%Y%m%d).mp3"

# Read the text file if it exists, otherwise use default
if [ -f "$TEXT_FILE" ]; then
    TEXT=$(cat "$TEXT_FILE")
else
    TEXT="سلام. خلاصه اخبار اقتصادی این هفته آماده شد. لطفاً متن کامل را در تلگرام مشاهده کنید."
fi

echo "$TEXT"
