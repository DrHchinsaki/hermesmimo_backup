#!/usr/bin/env python3
"""
Test Google AI Studio API connectivity and available models
"""
import urllib.request
import json

API_KEY = "AQ.Ab8RN6LzBCg_aOPoaAId9Zxyeygf7d4EB9qSh6gmV7Befebfxg"

# List available models
url = f"https://generativelanguage.googleapis.com/v1beta/models?key={API_KEY}"

req = urllib.request.Request(url, headers={
    'User-Agent': 'Mozilla/5.0'
})

try:
    with urllib.request.urlopen(req, timeout=30) as response:
        result = json.loads(response.read().decode('utf-8'))
        
        print("Available models:")
        if 'models' in result:
            for model in result['models']:
                name = model.get('name', '')
                display = model.get('displayName', '')
                if 'tts' in name.lower() or 'audio' in name.lower() or 'flash' in name.lower():
                    print(f"  ✓ {name} ({display})")
        
except Exception as e:
    print(f"Error: {e}")
