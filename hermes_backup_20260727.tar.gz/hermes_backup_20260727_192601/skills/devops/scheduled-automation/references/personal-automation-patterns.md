# Personal Automation Patterns

Additional patterns for personal productivity automation discovered in real deployments.

## Shopping List System

Simple persistent list management for groceries/items.

### Data Structure (`~/.hermes/shopping_list/list.json`)

```json
{
  "items": [
    {"id": 1, "name": "Shir", "quantity": "1", "added_at": "2026-07-26T10:00:00"}
  ],
  "completed": [],
  "history": []
}
```

### User Interaction

**Add items:**
```
#shopping Shir, tokhm-e morgh, nan
```
or
```
Be list-e kharid ezafe kon: 2 litr shir
```

**Remove (when purchased):**
```
List-e kharid: shomare 1 va 2 ro kharidam
```

**View list:**
```
List-e kharid chiye?
```

### Hashtag: `#shopping`

### Script
- `scripts/shopping_list.py` — Add/remove/list items

## Date-Based Reminders

For recurring annual/monthly reminders (anniversaries, birthdays).

### Monthly Reminder Pattern

```python
cronjob(
    action="create",
    schedule="30 18 16 * *",  # 16th of every month at 18:30 UTC (20:00 Tehran)
    prompt="Send romantic reminder about monthly anniversary...",
    deliver="telegram"
)
```

### Annual Reminder Pattern

For birthdays or yearly events, remind on multiple days leading up:

```python
cronjob(
    action="create",
    schedule="30 18 8,9,10,11 1 *",  # Jan 8-11 at 18:30 UTC
    prompt="Birthday reminder for [Name]...",
    deliver="telegram"
)
```

### Persian Calendar Dates

For users in Iran, important dates are often in Persian calendar:
- Dey 21 (تولد) ≈ January 11 (Gregorian)
- Remind from Dey 18 (≈ January 8) for 4 days

**Conversion tip:** Persian calendar months roughly map to:
| Persian Month | Gregorian Equivalent |
|---------------|---------------------|
| Farvardin | March 21 - April 20 |
| Ordibehesht | April 21 - May 21 |
| Khordad | May 22 - June 21 |
| Tir | June 22 - July 22 |
| Mordad | July 23 - August 22 |
| Shahrivar | August 23 - September 22 |
| Mehr | September 23 - October 22 |
| Aban | October 23 - November 21 |
| Azar | November 22 - December 21 |
| Dey | December 22 - January 20 |
| Bahman | January 21 - February 19 |
| Esfand | February 20 - March 20 |

## Mandatory Daily Tasks

Auto-add non-negotiable tasks to every day's task list.

### Pattern

In morning task check-in prompt, always include:

```
Your daily mandatory tasks:
1. Walking/Treadmill - 20 minutes minimum
2. Exercise/Workout

What other tasks do you have today?
```

### Evening Report Emphasis

```
Daily Mandatory Tasks:
1. Walking/Treadmill: [DONE/PENDING]
2. Exercise/Workout: [DONE/PENDING]
```

## Reminder Frequency Preferences

Users may prefer different reminder intervals:
- **Default:** Every 30 minutes
- **Some users:** Every 2 hours (less intrusive)
- **Heavy users:** Every hour

Ask user preference during setup and adjust cron schedule accordingly.

**Schedule conversion:**
| Preference | Cron Schedule |
|------------|---------------|
| Every 30 min | `every 30m` |
| Every 1 hour | `every 60m` |
| Every 2 hours | `every 120m` |

## Timezone-Sensitive Scheduling

When user specifies times, ALWAYS confirm timezone:

```
The times you mentioned - are these in Tehran time?
I'll set up the cron jobs to match your local timezone.
```

**Common mistake:** Assuming UTC when user means local time.

**Tehran conversion:** UTC = Tehran - 3:30

| Tehran Time | UTC Time |
|-------------|----------|
| 7:00 AM | 3:30 AM |
| 9:00 AM | 5:30 AM |
| 1:00 PM | 9:30 AM |
| 8:00 PM | 4:30 PM |
| 10:00 PM | 6:30 PM |
