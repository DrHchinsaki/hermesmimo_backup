---
name: scheduled-automation
description: "Cron jobs, backups, and recurring pipelines in Hermes."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [cron, automation, backup, scheduled-tasks, github, devops]
  related_skills: [financial-market-intel, github-repo-management, github-auth]
---

# Scheduled Automation

Patterns for recurring automated tasks in Hermes: cron jobs, data collection pipelines, and automated backups. Captures reusable patterns and pitfalls across automation use cases.

## Use When

- User wants something to run on a schedule (daily, weekly, every N days)
- User wants automated backups to GitHub or other remote storage
- User wants recurring data collection from APIs
- User wants reports delivered to Telegram/Discord on a schedule
- Setting up cron jobs with scripts that collect data

## Cron Job Setup Pattern

### Step 1: Create the Data Collection Script

Place scripts in `~/.hermes/scripts/` with a descriptive name:

```python
#!/usr/bin/env python3
"""Script to collect data. stdout is injected into agent prompt."""
import urllib.request
import json

def main():
    url = "https://api.example.com/data"
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    
    with urllib.request.urlopen(req, timeout=30) as response:
        data = json.loads(response.read().decode('utf-8'))
    
    print(json.dumps(data, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
```

### Step 2: Create the Cron Job

```python
cronjob(
    action="create",
    schedule="0 9 * * 0",      # Cron syntax or "every 3 days"
    prompt="Summarize the following data...",
    script="my_script.py",      # Relative to ~/.hermes/scripts/
    deliver="telegram",
    name="Descriptive Job Name"
)
```

### Step 3: Configure the Model

**Critical** — jobs fail without a model:

```python
cronjob(
    action="update",
    job_id="<id>",
    model={"model": "Hermes-mimo", "provider": "openai-api"}
)
```

## Critical Pitfalls

### 0. Timezone Mismatch (CRITICAL)
**Error:** Cron jobs run on UTC by default, not the user's local time.
**Symptom:** User receives messages at wrong times (e.g., 9 AM UTC = 12:30 PM Tehran).
**Fix:** Always ask the user's timezone and convert schedules accordingly.

**Common timezone offsets:**
| Timezone | Offset from UTC |
|----------|-----------------|
| Tehran (IRST) | UTC+3:30 |
| Dubai (GST) | UTC+4 |
| London (GMT) | UTC+0 |
| New York (EST) | UTC-5 |
| Los Angeles (PST) | UTC-8 |

**Conversion formula:** UTC = UserTime - Offset

**Example (Tehran):**
- User wants 9:00 AM Tehran → UTC = 9:00 - 3:30 = 5:30 UTC → `"30 5 * * *"`
- User wants 8:00 PM Tehran → UTC = 20:00 - 3:30 = 16:30 UTC → `"30 16 * * *"`

**Pattern:** When setting up cron jobs, ALWAYS confirm timezone with user and convert. Write a comment in the prompt like: `# Schedule: 9 AM Tehran = 5:30 UTC`

### 1. Model Not Configured
**Error:** `RuntimeError: Cron job has no model configured`
**Fix:** Always run `cronjob(action="update", job_id=..., model=...)` after creation.

### 2. Wrong Provider Name
**Error:** `RuntimeError: Unknown provider 'openai'`
**Fix:** Use exact provider name. Common: `"openai-api"` not `"openai"`. Check with `hermes model`.

### 3. Absolute Script Path
**Error:** `Script path must be relative to ~/.hermes/scripts/`
**Fix:** Use filename only: `script="my_script.py"`, NOT full path.

### 4. Git Identity Not Set
**Error:** `fatal: unable to auto-detect email address`
**Fix:** Configure before automated commits:
```bash
git config --global user.email "backup@agent"
git config --global user.name "Hermes Agent"
```

### 5. SSH Port Closed
**Error:** `ssh: connect to host github.com port 22: Connection refused`
**Fix:** Use HTTPS with token: `https://${TOKEN}@github.com/owner/repo.git`

### 6. Invisible Unicode in Prompts
**Error:** `Blocked: prompt contains invisible unicode U+200C (possible injection).`
**Cause:** Copy-pasting Persian/Arabic text into cron prompts can embed invisible Unicode characters (ZWNJ, zero-width joiners, etc.)
**Fix:** Rewrite the prompt in plain ASCII. Avoid copy-pasting from rich text editors. For Persian prompts, use transliteration or keep prompts in English.

### 7. Cron Prompt Too Long
**Error:** Prompt gets truncated or blocked
**Cause:** Some providers have prompt length limits
**Fix:** Keep cron job prompts concise. Use scripts for data collection, prompts for analysis instructions only.

## Automated Backup Pattern

For periodic backups to GitHub (see `references/automated-backup-patterns.md`):

```bash
#!/bin/bash
set -e
REPO_URL="https://${ACCESS_TOKEN}@github.com/owner/repo.git"
BACKUP_FILE="backup_$(date +%Y%m%d).tar.gz"

tar -czf "/tmp/$BACKUP_FILE" -C ~/.hermes \
    memories/ SOUL.md config.yaml skills/ scripts/ cron/jobs.json

git config --global user.email "backup@agent"
git config --global user.name "Hermes Agent"

REPO_DIR="/tmp/backup_repo"
rm -rf "$REPO_DIR"
git clone "$REPO_URL" "$REPO_DIR" 2>/dev/null || {
    mkdir -p "$REPO_DIR" && cd "$REPO_DIR" && git init
    git remote add origin "$REPO_URL"
}
cp "/tmp/$BACKUP_FILE" "$REPO_DIR/"
cd "$REPO_DIR"
git add . && git commit -m "Backup: $(date)" && git push origin main
rm -rf "$REPO_DIR" "/tmp/$BACKUP_FILE"
```

## Schedule Syntax Reference

| Format | Example | Meaning |
|--------|---------|---------|
| Duration | `"30m"`, `"2h"`, `"1d"` | Every N minutes/hours/days |
| Cron | `"0 9 * * *"` | Daily at 9am |
| Cron | `"0 9 * * 0"` | Every Sunday at 9am |
| Cron | `"0 10 */3 * *"` | Every 3 days at 10am |

## What to Backup (Hermes)

| Path | Contents | Priority |
|------|----------|----------|
| `memories/` | User memory, agent notes | Critical |
| `SOUL.md` | Agent personality | Critical |
| `config.yaml` | Configuration | High |
| `skills/` | All installed skills | High |
| `cron/jobs.json` | Scheduled jobs | Medium |
| `scripts/` | Custom scripts | Medium |

**Never backup:** `.env`, `auth.json`, `*.lock`, `sessions/`, `logs/`, `*.db` (while in use)

## User Preference: Reminder Frequency

Users have different preferences for reminder frequency. Some prefer more frequent reminders (every 30 minutes), others prefer less intrusive (every 2 hours).

**Pattern:** When setting up task reminders, ask the user their preference:
- "How often should I remind you? Every 30 minutes or every 2 hours?"

**Default:** Start with every 2 hours (less intrusive). User can always request more frequent reminders later.

**Implementation:**
```python
# Less frequent (preferred by most users)
schedule="every 120m"

# More frequent (for users who want constant reminders)
schedule="every 30m"
```

## Model Selection Strategy

### Task Complexity → Model Mapping

Different tasks need different model tiers. Users often have mixed provider access (e.g., free OpenRouter + paid Gemini Pro).

| Task Type | Recommended Tier | Example |
|-----------|------------------|---------|
| 📊 Complex analysis (financial, research) | Best available | `gemini-2.5-pro` |
| 🔄 Routine monitoring (hourly checks) | Fast/cheap | `gemini-2.5-flash` |
| 💾 Simple operations (backups, alerts) | Any capable | `Hermes-mimo` |

### Provider Access Patterns

**Free tier (OpenRouter):**
- Only use models with `:free` suffix
- Best: `nvidia/nemotron-3-ultra-550b-a55b:free` (1M context)
- Good: `google/gemma-4-31b-it:free`, `openai/gpt-oss-20b:free`

**Paid tier (Gemini Pro):**
- All models available
- Complex tasks: `gemini-2.5-pro`
- Fast tasks: `gemini-2.5-flash`

**User preference:** When user says "this is complex work," assign the best model from their available providers.

## Provider Authentication Failures & Fallback

### Common Gemini API Errors

| HTTP Error | Meaning | Fix |
|------------|---------|-----|
| `403: Your project has been denied access` | API key lacks permissions or project not enabled for Generative Language API | Switch to another provider |
| `429: You exceeded your current quota` | Rate limit or billing issue | Wait or switch provider |
| `404: Not Found` | Wrong model name or endpoint | Check model name |

**Critical:** These are account-level failures, NOT transient. Do NOT retry — switch provider immediately.

### Provider Fallback Strategy

When setting up cron jobs, always have a fallback plan:

```python
# Primary: Best model from paid provider (if available)
# Fallback: Free model from OpenRouter

# If primary fails mid-session, update job to use fallback:
cronjob(action="update", job_id="<id>",
        model={"model": "nvidia/nemotron-3-ultra-550b-a55b:free", 
               "provider": "openrouter"})
```

### OpenRouter Free Tier Rules

- **Only use models with `:free` suffix** — paid models fail silently or with auth error
- No authentication issues — just works
- Best free models (2026): `nemotron-3-ultra:free` (1M ctx), `gemma-4-31b:free` (262K), `gpt-oss-20b:free` (131K)

### Google Gemini API Key Gotcha

Google AI Studio API key (`GOOGLE_API_KEY`) may work for some services (TTS) but NOT for Generative Language API unless:
1. Project has Generative Language API enabled in Google Cloud Console
2. Billing is enabled (even for free tier)
3. API key was created for the correct service

**Workaround:** If Gemini fails, OpenRouter free tier is reliable for all cron jobs.

## Silent / Suppressed Delivery (`[SILENT]`)

**CRITICAL for spam-free automation.** When a cron job has nothing to report, using `[SILENT]` suppresses ALL delivery (both DM and group).

**Symptom:** Tokens like `[NO_NEWS]`, `[NO_EVENTS]`, `[NO_NEW_STORIES]` may still trigger delivery, especially with multi-channel deliver configs like `\"origin,telegram:...\"`.

**Fix in prompt:** Use `[SILENT]` instead of ad-hoc tokens:

```
If there is nothing to report, respond with EXACTLY:
[SILENT]

Do NOT add any other text when there is nothing to report.
```

**When to use:**
| Scenario | Token | Result |
|----------|-------|--------|
| No news/events/change | `[SILENT]` | ✅ Nothing sent anywhere |
| News/events to report | Full analysis | ✅ Delivered to all channels |

## Multi-Channel Delivery

Jobs can deliver to multiple destinations simultaneously:

```python
deliver="origin,telegram:-1004281458610"   # DM + specific group
deliver="origin,all"                        # DM + all connected channels
deliver="telegram:-1004281458610"           # Group only (no DM)
```

### Bot Must Be Group Member

**Error:** `Forbidden: bot is not a member of the supergroup chat`

**Fix:** Manually add the bot to the Telegram group before delivery works.

### Hashtag Convention Per Channel

When delivering to both DM and a group, hashtags differ:
- **Group:** Only the group's approved hashtag (e.g., `#News`)
- **DM:** Full hashtag set for search/filtering

Structure the prompt to make this clear, e.g.: \"Add hashtag #News at the end for group messages.\"

## Bulk Cron Job Model Updates

When migrating many jobs (e.g., 14 jobs from OpenRouter to Gemini):

**Steps:**
1. `cronjob(action=\"list\")` to get all job IDs
2. Batch update all jobs in a single turn (parallel execution)
3. Test one with `cronjob(action=\"run\", job_id=\"<id>\")`
4. Check for auth errors before assuming success

**Pattern:** If the new provider fails auth (403/429), ALL jobs fail. Always test one before migrating the rest.

**Preferred migration order:** Test a single job on new provider first, then bulk update.

## Related Skills

- `financial-market-intel` — Financial data collection (specific use case)
- `github-auth` — GitHub authentication setup
- `github-repo-management` — Repository operations
