---
name: trading-journal-forex
description: "Record forex trades, track PnL and store screenshots."
category: trading
---

# Trading Journal (Forex)

## When to use

A forex trader (usually Persian-speaking, Tehran timezone) asks you to:
- Record a new trade entry (entry, TP, SL, strategy, mindset)
- Store a screenshot alongside the trade
- Record the result (win/loss, PnL)
- Generate a performance summary or report
- Track statistics over time

Do **NOT** use this for: general market analysis requests, economic calendar queries, or one-off price checks.

## Workflow

### Step 1: Receive trade entry

Parse user data into:

| Field | Example |
|-------|---------|
| Pair | `XAUUSD`, `EURUSD` |
| Direction | `BUY` / `SELL` |
| Entry price | `4089.79` |
| TP | `4021.62` |
| SL | `4098.26` |
| Strategy | `بر مبنای روند` |
| Mindset | `متمرکز و آرام` |
| Screenshot | attached image |

Save screenshot: `screenshots/trade_<id>_<pair>.jpg`

### Step 2: Register with journal script

```bash
cd /data/.hermes/trading_journal/scripts
python3 add_trade.py add <PAIR> <DIRECTION> <ENTRY> <TP> <SL> "<STRATEGY>" "<MINDSET>" [screenshot_path]
```

### Step 3: Record result when trade closes

User reports exit price, win/loss, PnL. Use Python to update `trades.json`.

### Step 4: Generate summary on demand

```bash
cd /data/.hermes/trading_journal/scripts
python3 generate_report.py summary
```

## Pitfalls

### ❌ Do NOT analyze the trade
Record only. No chart interpretation, no TP/SL suggestions, no market commentary.

### ❌ Do NOT comment on PnL
No "good trade" / "bad trade" — just record the numbers.

### ❌ Do NOT over-format
Clean tables. `#Trade` in private, `#News` in group.

### ✅ Always store screenshots if provided

### ✅ Tehran timezone (UTC+3:30) for all timestamps

## User preferences

- Persian (Farsi) for trade communication
- Hashtags: `#Trade` private, `#News` group
- Tehran timezone
- Zero analytical depth — record only
- Anti-spam: silent when no trades exist
