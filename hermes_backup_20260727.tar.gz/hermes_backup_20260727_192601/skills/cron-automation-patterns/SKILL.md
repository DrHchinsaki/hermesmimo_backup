---
name: cron-automation-patterns
description: Cron job and API automation patterns for Hermes workflows.
version: 1.0.0
created_by: agent
---

# Cron Automation Patterns

## Overview
Pattern library for creating automated workflows using Hermes cron jobs, pre-run scripts, and multi-provider model configurations.

## Key Patterns

### 1. Script + Cron Job Architecture

**Standard flow:**
1. Create Python script in ~/.hermes/scripts/ for data collection
2. Create cron job with script: parameter pointing to the script
3. Agent prompt processes script output and generates response
4. Use deliver: telegram for notification

### 0. Pre-Flight Provider Checks (CRITICAL)

**Before setting up ANY cron job, ALWAYS test the provider/model:**
1. Test API key validity (see `references/provider-troubleshooting.md`)
2. Test model inference with a simple prompt
3. Only then create cron jobs
4. After creation, run job immediately to confirm

Failure to pre-flight leads to silent cron failures that the user discovers hours later.

### 2. API Key Testing Workflow

**CRITICAL: Always test API keys BEFORE configuring cron jobs.**

Common errors:
- HTTP 403: Project not enabled or denied access
- HTTP 429: Quota exceeded
- HTTP 401: Invalid API key

Fallback strategy: If primary provider fails, immediately switch to working provider.

### 3. Multi-Provider Model Assignment

Assign models based on task complexity:
- Complex analysis: nvidia/nemotron-3-ultra-550b-a55b:free (OpenRouter)
- Quick monitoring: nvidia/nemotron-3-super-120b-a12b:free (OpenRouter)
- Simple tasks: nvidia/nemotron-3-nano-30b-a3b:free (OpenRouter)
- Pro account: gemini-2.5-pro (Gemini)
- Fast response: gemini-2.5-flash (Gemini)

### 4. TTS Quality Considerations

Persian/Farsi TTS: Often poor quality with most providers.
English TTS: Generally high quality, natural sounding.

Recommendation: For voice summaries, generate in English even if user communicates in Persian.

### 5. Hashtag Convention

**CRITICAL:** Hashtag usage differs between DM and group messages.

**Group Messages:**
- ONLY use `#News` for all group messages
- Do NOT use other hashtags in group
- User's full group hashtag set (for reference, but only use #News): `#Chinaski`, `#Potato`, `#Analysis`, `#News`, `#Note`, `#Trade`, `#Backtest`, `#Update`, `#Quotes`

**DM Messages (Private Chat):**
Use full hashtag set for easy filtering:
- #econweekly - Weekly economic summary
- #econalerts - Real-time economic alerts
- #forexnews - Forex news
- #backup - Backup reports
- #dailytasks - Daily tasks
- #reminder - Task reminders
- #dailyreport - Daily reports
- #weight - Weight tracking
- #calories - Calorie tracking
- #trading - Trading journal

### 6. Silent Mode for No-News (CRITICAL)

Use `[SILENT]` to suppress ALL delivery when there's nothing to report:
```
If no news, respond with EXACTLY:
[SILENT]
```

**Why [SILENT] over [NO_NEWS]/[NO_EVENTS]:** The old patterns used `[NO_NEW_NEWS]` and `[NO_EVENTS]`, but these still got delivered as messages to the chat/group — creating spam. `[SILENT]` is the official token that suppresses ALL delivery to both DM and group. If the user complains about empty messages in the group, change `[NO_NEW_NEWS]` → `[SILENT]` in both the script output and the cron prompt. **This applies to every cron job** — if it has nothing to report, it must output nothing visible.

**Double-check deliver target**: Even `[SILENT]` in the prompt won't help if the script prints text that the cron prompt then wraps in a message. The script itself must output `NO_NEW_NEWS` or nothing, and the cron prompt must check the count/value before producing any output. Pattern:
```
Script output:
  If nothing new: print("0")  # bare numeric
Cron prompt:
  If output is "0" or "NO_NEW_NEWS": respond with [SILENT]
  Otherwise: format and send
```

### 7. Group Delivery Privacy

**CRITICAL:** Group messages are ONE-WAY only (send only).

- Bot SENDS messages to group ✅
- Bot does NOT read/monitor group messages ❌
- User communicates with bot via DM only
- If user wants to send something to group, they tell bot in DM
- **User confirmation (actual):** "من اگه توی گروه صحبت کنم تو نمیفهمی من چی میگم چون نمیخوام به پیام های گروه دسترسی داشته باشی" — The user explicitly confirmed they do NOT want the bot reading group messages.

**Pattern:** User says "توی گروه این رو بفرست: [message]" → Bot sends to group.

### 8. Hashtag Routing Per Channel

Daily check-in flow:
1. Morning: Ask for tasks/weight
2. Throughout day: Send reminders 30 min before tasks
3. Evening: Send completion report

Trading journal flow:
1. User sends position with screenshot
2. System stores entry, TP, SL, strategy, mindset
3. User later reports result (TP/SL hit)
4. System generates performance reports

## Pitfalls

1. **Timezone mismatch (CRITICAL)** - Cron jobs run on UTC by default. ALWAYS ask user's timezone and convert. Example: Tehran (UTC+3:30) 9 AM = 5:30 UTC → `30 5 * * *`.
2. Never assume API keys work - Always test before configuring cron jobs
3. Persian TTS quality - Use English for voice summaries
4. Invisible unicode characters - Can cause prompt injection errors
5. Model availability - Free models may have rate limits; have fallback ready
6. Script paths - Cron job scripts must be relative to ~/.hermes/scripts/
7. **Free tier rate limits (CRITICAL for multiple cron jobs)** - OpenRouter free tier (`is_free_tier: true`) has a strict daily request cap (~1000/day for users with $10+ balance, much lower for $0 balance). With 10+ cron jobs running every 1-2 hours, this cap can be exhausted in hours, not days. Mitigation strategies:
   - Spread cron jobs across providers (OpenRouter + Gemini + fallbacks)
   - Increase intervals for lower-priority jobs (e.g. 2h → 4h)
   - Detect rate limit errors (HTTP 429) vs auth errors (HTTP 401/403) — they require different fixes
   - For OpenRouter free: adding $10 unlocks 1000 free model requests per day
8. **Provider fallback chain** - Cron jobs do NOT automatically fall back to another provider when one fails. The model/provider is pinned at creation time. If the provider is down or out of credits, the job fails hard. Keep a copy of a working fallback provider config and swap when needed.
9. **API key format confusion** - Different providers use different auth formats. Google AI Studio API keys (format: AIza... or AQ.Ab...) may fail with ACCESS_TOKEN_TYPE_UNSUPPORTED because they need OAuth 2.0 or Cloud Console key with Generative Language API enabled.
   - **Diagnosis:** `curl -s "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$KEY" -H "Content-Type: application/json" -d '{"contents":[{"parts":[{"text":"hi"}]}]}'` → 401/ACCESS_TOKEN_TYPE_UNSUPPORTED means the key format is incompatible with the REST API.
   - **Fix:** User needs a Cloud Console API key (not AI Studio) with Generative Language API enabled, OR use Google's client libraries.
   - OpenRouter keys (sk-or-v1-...) work as simple Bearer tokens. Always test before wiring into cron jobs. **Diagnostic commands:**
     - OpenRouter: `curl -s https://openrouter.ai/api/v1/auth/key -H "Authorization: Bearer $KEY"` → check `is_free_tier`, `limit_remaining`, `usage`
10. **Mass provider migration (CRITICAL for 10+ cron jobs)** - When all cron jobs share one provider and it fails (rate limit, auth error), update ALL jobs at once. The pattern: use cronjob(action='update', job_id, model) in a batch call to update every job in one turn. Do NOT migrate one-by-one — the user will tell you everything failed anyway. Always test the new provider with a single cronjob(action='run') before walking away.
11. **Custom proxy/combo endpoints** - Some installations use a private OpenAI-compatible proxy (e.g. via `openai-api` provider). This can serve as a stable fallback when mainstream free providers are rate-limited or fail auth. The model name (e.g. `mycombo`) is arbitrary — what matters is the provider (`openai-api`) and the `base_url` pointing to the proxy.

## Script Templates

Scripts directory contains:
- forex_factory_news.py - Forex Factory data fetcher (calendar)
- forex_event_monitor.py - Real-time event monitor (calendar_data)
- `forex_news_monitor.py` - News monitor using calendar as fallback (see references/forex-factory-api.md for why). Uses `[SILENT]` on no-news to suppress delivery entirely.
- `news_feed.py` - Multi-source news aggregator at /data/.hermes/news_feed/scripts/
- backup_hermes.sh - GitHub backup script
- task_manager.py - Daily task management
- weight_tracker.py - Weight loss tracking
- calorie_tracker.py - Calorie intake tracking
- prepare_voice_summary.sh - Voice summary generation (deprecated: user stopped wanting voice)

## Daily Routine Scripts (under /data/.hermes/)

### Task Management
- **Location:** `/data/.hermes/task_manager/scripts/task_manager.py`
- **Data:** `/data/.hermes/task_manager/tasks.json`
- Commands: `add`, `complete`, `list`, `reminders`, `stats`

### Weight Tracking
- **Location:** `/data/.hermes/weight_tracker/scripts/weight_tracker.py`
- **Data:** `/data/.hermes/weight_tracker/weight.json`
- Commands: `add <weight>`, `progress`, `recent [days]`, `weekly`

### Calorie Tracking
- **Location:** `/data/.hermes/calorie_tracker/scripts/calorie_tracker.py`
- **Data:** `/data/.hermes/calorie_tracker/calories.json`
- Commands: `add <meal_type> <food> <calories>`, `snack <food> <calories>`, `status`

### Trading Journal
- **Location:** `/data/.hermes/trading_journal/`
- **Data:** `/data/.hermes/trading_journal/trades.json`
- **Screenshots:** `/data/.hermes/trading_journal/screenshots/`

### Shopping List
- **Location:** `/data/.hermes/shopping_list/`
- **Data:** `/data/.hermes/shopping_list/list.json`
- Commands: `add <item> [quantity]`, `remove <id>`, `list`, `clear`

### Meeting Preparation
- **Location:** `/data/.hermes/meetings/`
- **Pattern:** Ask client questions → research market (competitor analysis) → create briefing document
- **Workflow:**
  1. Ask the user about the meeting context (who, what, when)
  2. Research the client's industry/market (competitors, trends, pricing)
  3. Create a structured briefing document at `/data/.hermes/meetings/<project>.md`
  4. Include: agenda, talking points, key phrases, client questions to ask, pricing packages
  5. Review before the meeting

### News Feed (Multi-Source Aggregator)
- **Location:** `/data/.hermes/news_feed/`
- **Data:** `/data/.hermes/news_feed/news.json`
- **Sources (auto):** Forex Factory calendar (High/Medium impact events), Investing.com RSS, DailyFX RSS
- **Manual:** User can submit custom news
- **Auto-fetch:** Every 2h via cron job, deduplicates by title
- **Commands:**
  - `python3 news_feed.py fetch` — Fetch from all sources
  - `python3 news_feed.py add "<title>" [category] [url]` — Manual add
  - `python3 news_feed.py recent [hours]` — Show recent news
  - `python3 news_feed.py source <name>` — News by source
  - `python3 news_feed.py stats` — Show statistics

## Referenced Files

- `references/forex-factory-api.md` — Available Forex Factory endpoints, their status, and data formats
- `references/user-sina-profile.md` — User-specific preferences for communication, trading journal, and provider setup