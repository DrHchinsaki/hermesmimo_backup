#!/usr/bin/env python3
"""
Task Manager - Daily Task Management System
Manages tasks with reminders and tracking
"""
import json
import os
from datetime import datetime, timedelta

TASKS_PATH = "/data/.hermes/task_manager/tasks.json"

def load_tasks():
    if os.path.exists(TASKS_PATH):
        with open(TASKS_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"tasks": [], "completed": [], "pending": [], "stats": {}, "daily_logs": {}}

def save_tasks(data):
    with open(TASKS_PATH, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def add_task(task_text, task_time=None, priority="normal"):
    db = load_tasks()
    
    task = {
        "id": len(db["tasks"]) + 1,
        "text": task_text,
        "time": task_time,
        "priority": priority,
        "status": "pending",
        "reminder_sent": False,
        "created_at": datetime.now().isoformat(),
        "date": datetime.now().strftime("%Y-%m-%d"),
        "completed_at": None
    }
    
    db["tasks"].append(task)
    db["pending"].append(task["id"])
    db["stats"]["total_tasks"] = len(db["tasks"])
    db["stats"]["pending_tasks"] = len(db["pending"])
    
    today = datetime.now().strftime("%Y-%m-%d")
    if today not in db["daily_logs"]:
        db["daily_logs"][today] = {"tasks": [], "completed": 0, "pending": 0}
    db["daily_logs"][today]["tasks"].append(task["id"])
    db["daily_logs"][today]["pending"] += 1
    
    save_tasks(db)
    return task

def complete_task(task_id):
    db = load_tasks()
    
    for task in db["tasks"]:
        if task["id"] == task_id:
            task["status"] = "completed"
            task["completed_at"] = datetime.now().isoformat()
            
            if task_id in db["pending"]:
                db["pending"].remove(task_id)
            db["completed"].append(task_id)
            
            db["stats"]["completed_tasks"] = len(db["completed"])
            db["stats"]["pending_tasks"] = len(db["pending"])
            total = db["stats"]["total_tasks"]
            db["stats"]["completion_rate"] = round((len(db["completed"]) / total * 100) if total > 0 else 0, 1)
            
            today = task.get("date", datetime.now().strftime("%Y-%m-%d"))
            if today in db["daily_logs"]:
                db["daily_logs"][today]["completed"] += 1
                db["daily_logs"][today]["pending"] -= 1
            
            save_tasks(db)
            return task
    
    return None

def get_pending_tasks():
    db = load_tasks()
    return [t for t in db["tasks"] if t["status"] == "pending"]

def get_tasks_needing_reminder():
    db = load_tasks()
    now = datetime.now()
    reminders = []
    
    for task in db["tasks"]:
        if task["status"] == "pending" and task.get("time") and not task.get("reminder_sent"):
            try:
                task_time = datetime.strptime(f"{task.get('date', now.strftime('%Y-%m-%d'))} {task['time']}", "%Y-%m-%d %H:%M")
                diff = (task_time - now).total_seconds() / 60
                
                if 0 <= diff <= 30:
                    reminders.append(task)
            except:
                continue
    
    return reminders

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: task_manager.py <command> [args]")
        print("Commands: add, complete, pending, reminders, stats")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "add" and len(sys.argv) >= 3:
        task = add_task(
            task_text=sys.argv[2],
            task_time=sys.argv[3] if len(sys.argv) > 3 else None,
            priority=sys.argv[4] if len(sys.argv) > 4 else "normal"
        )
        print(f"Task #{task['id']} added: {task['text']}")
    
    elif command == "complete" and len(sys.argv) >= 3:
        task = complete_task(int(sys.argv[2]))
        if task:
            print(f"Task #{task['id']} completed: {task['text']}")
        else:
            print("Task not found")
    
    elif command == "pending":
        tasks = get_pending_tasks()
        if tasks:
            for t in tasks:
                time_str = f" @ {t['time']}" if t.get('time') else ""
                print(f"#{t['id']}: {t['text']}{time_str}")
        else:
            print("No pending tasks")
    
    elif command == "reminders":
        tasks = get_tasks_needing_reminder()
        if tasks:
            for t in tasks:
                print(f"REMINDER #{t['id']}: {t['text']} @ {t['time']}")
        else:
            print("No reminders needed")
    
    elif command == "stats":
        db = load_tasks()
        stats = db["stats"]
        print(f"Total: {stats.get('total_tasks', 0)}")
        print(f"Completed: {stats.get('completed_tasks', 0)}")
        print(f"Pending: {stats.get('pending_tasks', 0)}")
        print(f"Rate: {stats.get('completion_rate', 0)}%")
