#!/usr/bin/env python3
"""
Forex Factory Economic Calendar Fetcher
Fetches weekly economic calendar data for cron jobs
"""
import urllib.request
import json
from datetime import datetime

def fetch_forex_factory():
    """Fetch economic calendar from Forex Factory JSON API."""
    url = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
    
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
    })
    
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            data = json.loads(response.read().decode('utf-8'))
            return data
    except Exception as e:
        return {"error": str(e)}

def format_importance(impact):
    mapping = {"High": "High", "Medium": "Medium", "Low": "Low"}
    return mapping.get(impact, impact)

def main():
    data = fetch_forex_factory()
    
    if "error" in data:
        print(json.dumps({"error": data["error"]}, ensure_ascii=False))
        return
    
    important_events = []
    for event in data:
        importance = event.get('impact', '')
        if importance in ['High', 'Medium']:
            important_events.append({
                'title': event.get('title', ''),
                'currency': event.get('currency', ''),
                'importance': format_importance(importance),
                'date': event.get('date', ''),
                'forecast': event.get('forecast', ''),
                'previous': event.get('previous', '')
            })
    
    events_by_date = {}
    day_names = {0: 'Monday', 1: 'Tuesday', 2: 'Wednesday', 3: 'Thursday', 4: 'Friday', 5: 'Saturday', 6: 'Sunday'}
    
    for event in important_events:
        try:
            dt = datetime.fromisoformat(event['date'].replace('Z', '+00:00'))
            day_name = day_names.get(dt.weekday(), '')
            date_display = f"{day_name} {dt.strftime('%d/%m')}"
        except:
            date_display = event['date']
        
        if date_display not in events_by_date:
            events_by_date[date_display] = []
        events_by_date[date_display].append(event)
    
    output = {
        "week_start": datetime.now().strftime('%Y-%m-%d'),
        "total_events": len(data),
        "important_events": len(important_events),
        "events_by_date": events_by_date
    }
    
    print(json.dumps(output, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
