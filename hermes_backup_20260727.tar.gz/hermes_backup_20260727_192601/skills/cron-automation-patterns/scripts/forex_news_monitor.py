#!/usr/bin/env python3
"""
Forex Factory - Today's High Impact News Monitor
Fetches today's important economic events as "hot stories"

Uses ff_calendar_thisweek.json as a fallback since ff_news.json 
returns 404 and forexfactory.com is behind Cloudflare.

Filters to High/Medium impact events only.
Deduplicates against a local cache file.
"""
import urllib.request
import json
from datetime import datetime

CALENDAR_URL = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
CACHE_FILE = "/data/.hermes/cron/output/forex_news_cache.json"

def fetch_calendar():
    req = urllib.request.Request(CALENDAR_URL, headers={
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
    })
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode('utf-8'))

def get_today_events():
    events = fetch_calendar()
    today = datetime.now()
    today_events = []
    for event in events:
        event_date = datetime.fromisoformat(event['date'].replace('Z', '+00:00'))
        if event_date.date() == today.date():
            today_events.append({
                'title': event['title'],
                'country': event['country'],
                'impact': event['impact'],
                'time': event_date.strftime('%H:%M'),
                'forecast': event.get('forecast', ''),
                'previous': event.get('previous', '')
            })
    return today_events

def load_cache():
    try:
        with open(CACHE_FILE, 'r') as f:
            return json.load(f)
    except:
        return {'sent_titles': [], 'last_check': None}

def save_cache(cache):
    import os
    os.makedirs(os.path.dirname(CACHE_FILE), exist_ok=True)
    with open(CACHE_FILE, 'w') as f:
        json.dump(cache, f)

def check_for_new_stories():
    try:
        today_events = get_today_events()
    except Exception as e:
        return {"error": str(e)}

    if not today_events:
        return {"stories": [], "count": 0, "has_new": False}

    important = [e for e in today_events if e['impact'] in ('High', 'Medium')]
    cache = load_cache()
    sent_titles = cache.get('sent_titles', [])
    new_stories = [e for e in important if e['title'] not in sent_titles]

    for story in new_stories:
        sent_titles.append(story['title'])
    sent_titles = sent_titles[-50:]
    save_cache({'sent_titles': sent_titles, 'last_check': datetime.now().isoformat()})

    return {
        "stories": new_stories,
        "count": len(new_stories),
        "total_today": len(important),
        "check_time": datetime.now().isoformat(),
        "has_new": len(new_stories) > 0
    }

if __name__ == "__main__":
    result = check_for_new_stories()
    if "error" in result:
        print(f"ERROR: {result['error']}")
    elif result["has_new"]:
        print(f"NEWS_FOUND: {result['count']} new stories ({result['total_today']} today)")
        for story in result["stories"]:
            flags = {'High': '🔴', 'Medium': '🟡'}
            flag = flags.get(story['impact'], '⚪')
            print(f"{flag} {story['time']} | {story['title']} | {story['country']} | F:{story['forecast']} P:{story['previous']}")
    else:
        print("NO_NEW_NEWS")
