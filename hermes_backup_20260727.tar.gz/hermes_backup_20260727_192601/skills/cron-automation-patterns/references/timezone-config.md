# Timezone Configuration Reference

## Common Timezones

| City | UTC Offset | Cron Example (9 AM local) |
|------|------------|---------------------------|
| Tehran | +3:30 | `30 5 * * *` |
| Dubai | +4 | `0 5 * * *` |
| Mumbai | +5:30 | `30 3 * * *` |
| Singapore | +8 | `0 1 * * *` |
| Tokyo | +9 | `0 0 * * *` |
| London | +0/+1 | `0 9 * * *` (winter) |
| New York | -5/-4 | `0 14 * * *` (winter) |
| Los Angeles | -8/-7 | `0 17 * * *` (winter) |

## Conversion Formula

```
UTC = Local Time - Offset
```

**Example (Tehran):**
- Tehran 9:00 AM = 9:00 - 3:30 = 5:30 UTC
- Cron: `30 5 * * *`

## Critical Pitfall

**CRITICAL:** Cron jobs run on UTC by default. ALWAYS ask user's timezone and convert.

**Wrong:** User in Tehran asks for "9 AM" → You set `0 9 * * *` (which is 12:30 PM Tehran!)
**Correct:** You set `30 5 * * *` (which is 9:00 AM Tehran)

## DST Considerations

Some timezones have Daylight Saving Time:
- London: GMT (winter) → BST (summer, +1)
- New York: EST (winter) → EDT (summer, +1)
- Tehran: No DST (fixed +3:30)

**Safe approach:** For fixed-offset timezones like Tehran, no DST adjustment needed.
