# Provider Troubleshooting Reference

## HTTP Status Code Quick Reference

| Code | Meaning | Typical Fix |
|------|---------|-------------|
| 401 | Unauthenticated (bad/no key) | Generate new API key or use correct auth format |
| 403 | Forbidden (no access) | Enable API/service in provider console |
| 429 | Rate limited (quotas exhausted) | Wait for reset, add credits, or switch provider |
| 500 | Server error | Retry or switch provider |

## Provider-Specific Diagnostics

### OpenRouter
- **Key format:** `sk-or-v1-...`
- **Test endpoint:** `curl -s https://openrouter.ai/api/v1/auth/key -H "Authorization: Bearer $KEY"`
- **Free tier:** `is_free_tier: true` in auth response — means daily request cap applies
- **Rate limit error:** "HTTP 429: Rate limit exceeded: free-models-per-day. Add 10 credits to unlock 1000 free model requests per day"
- **Fix:** Add minimum $10 to account, or wait for daily reset, or switch provider
- **Free models list:** Query `/api/v1/models` and filter where `pricing.prompt = 0` and `pricing.completion = 0`

### Google Gemini
- **Key format (AI Studio):** `AIza...` or `AQ.Ab...` — may require OAuth 2.0, not simple API key
- **Key format (Cloud Console):** Standard API key with Generative Language API enabled
- **Auth error:** "Request had invalid authentication credentials. Expected OAuth 2 access token, login cookie or other valid authentication credential."
- **Access denied:** "Your project has been denied access. Please contact support." — project not whitelisted
- **Fix:** Use Cloud Console API key with Generative Language API enabled, or use OAuth 2.0

### Custom OpenAI-Compatible Proxy Endpoints

Some Hermes installations use private OpenAI-compatible proxy endpoints (e.g. Railway-hosted proxies) instead of or alongside mainstream providers. These are configured via:
- Provider name: `openai-api`
- Model name: arbitrary (e.g. `mycombo`)
- `base_url`: The proxy URL (e.g. `https://9router-production-2ff9.up.railway.app/v1`)

**Characteristics:**
- Works with standard OpenAI SDK format
- Model name is abstracted by the proxy — the actual model running is whatever the proxy points to
- Can serve as a **stable fallback** when free-tier providers hit daily rate limits
- Auth via `OPENAI_API_KEY` env var

**Testing:**
```bash
curl -s "$OPENAI_BASE_URL/models" -H "Authorization: Bearer $OPENAI_API_KEY"
```

## Testing Workflow

1. Test the API key directly: `curl` to the provider's auth/model endpoint  
2. If auth works, test model inference with a simple prompt  
3. Only then wire the model/provider into cron jobs  
4. After wiring, run the cron job immediately to confirm it works
