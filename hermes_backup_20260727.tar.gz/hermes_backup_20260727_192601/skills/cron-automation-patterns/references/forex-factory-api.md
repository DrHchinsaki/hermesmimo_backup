# Forex Factory API Reference

## Endpoints

### Calendar Data (WORKING)
```json
GET https://nfs.faireconomy.media/ff_calendar_thisweek.json
```
Returns full array of weekly economic events with fields:
- `title`: Event name
- `country`: Currency code (USD, EUR, JPY, GBP, etc.)
- `date`: ISO timestamp (US Eastern timezone -04:00/-05:00)
- `impact`: "High", "Medium", or "Low"
- `forecast`: Market forecast value (string, may be empty)
- `previous`: Previous actual value (string, may be empty)

### Hot Stories / News (BROKEN)
```
GET https://nfs.faireconomy.media/ff_news.json
```
Returns 404 Not Found as of July 2026. Do NOT use.

### Live Calendar Data (WORKING for monitor)
```
GET https://nfs.faireconomy.media/ff_calendar_data.json
```
Used by forex_event_monitor.py for real-time event tracking.

## Usage Patterns

### Script Pattern
Script collects data and outputs structured text. The cron job's AI prompt then processes it. Two output modes:

1. **Silent when empty:** Script outputs `NO_NEW_NEWS` → AI sees this and returns `[SILENT]`
2. **Found data:** Script outputs `NEWS_FOUND: N stories` + details → AI formats and sends

### Cache Strategy
To avoid re-sending the same news, maintain a local cache file (e.g. `forex_news_cache.json`) tracking previously sent story titles. Keep last 50 entries.

### Calendar-Fallback News Monitor (WORKING fallback)

When `ff_news.json` (headline news) is dead and `forexfactory.com/news` is behind Cloudflare, use the calendar API as an alternative "news" source:

```python
GET https://nfs.faireconomy.media/ff_calendar_thisweek.json
```

Filter by `impact: "High"` or `"Medium"` for news-worthy items. Use a local cache to deduplicate already-reported titles.

**Script pattern example:**
- Script fetches today's events from calendar
- Filters to High/Medium impact only
- Compares against a local `forex_news_cache.json` (last 50 sent titles)
- If new titles found → outputs `NEWS_FOUND: N`
- If nothing new → outputs `NO_NEW_NEWS`

**Important:** Any calendar-fallback approach must track TITLES already sent, not just timestamps. The same event (e.g. "Federal Funds Rate") appears every 6 weeks — you must detect when it's truly a new occurrence or skip it.

### Event vs News
- **Events:** Scheduled economic releases (CPI, GDP, FOMC) — use `ff_calendar_thisweek.json`
- **News:** Breaking stories, analysis articles — requires scraping forexfactory.com/news directly as the JSON feed is dead
