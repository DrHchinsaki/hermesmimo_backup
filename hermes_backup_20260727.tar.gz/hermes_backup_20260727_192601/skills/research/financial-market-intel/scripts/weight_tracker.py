#!/usr/bin/env python3
"""
Weight Tracker - Daily Weight Management System
Tracks weight loss progress towards goal
"""
import json
import os
from datetime import datetime, timedelta

WEIGHT_PATH = os.path.expanduser("~/.hermes/weight_tracker/weight.json")

def load_data():
    if os.path.exists(WEIGHT_PATH):
        with open(WEIGHT_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {
        "goal": {"start_weight": 110, "target_weight": 80, "start_date": "2026-07-26"},
        "entries": [],
        "stats": {},
        "streaks": {"current": 0, "best": 0}
    }

def save_data(data):
    with open(WEIGHT_PATH, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def add_weight_entry(weight, note=""):
    data = load_data()
    entry = {
        "id": len(data["entries"]) + 1,
        "weight": float(weight),
        "date": datetime.now().strftime("%Y-%m-%d"),
        "time": datetime.now().strftime("%H:%M"),
        "note": note,
        "created_at": datetime.now().isoformat()
    }
    data["entries"].append(entry)
    data["stats"]["total_entries"] = len(data["entries"])
    data["stats"]["current_weight"] = float(weight)
    start_weight = data["goal"]["start_weight"]
    data["stats"]["total_lost"] = round(start_weight - float(weight), 1)
    save_data(data)
    return entry

def get_progress():
    data = load_data()
    goal = data["goal"]
    current = data["stats"].get("current_weight") or goal["start_weight"]
    start = goal["start_weight"]
    target = goal["target_weight"]
    lost = start - current
    remaining = current - target
    percentage = round((lost / (start - target) * 100) if (start - target) > 0 else 0, 1)
    return {
        "start_weight": start,
        "current_weight": current,
        "target_weight": target,
        "total_lost": round(lost, 1),
        "remaining": round(remaining, 1),
        "percentage": percentage
    }

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: weight_tracker.py <add|progress> [args]")
        sys.exit(1)
    command = sys.argv[1]
    if command == "add" and len(sys.argv) >= 3:
        entry = add_weight_entry(sys.argv[2])
        p = get_progress()
        print(f"Weight recorded: {entry['weight']} kg")
        print(f"Progress: {p['percentage']}% | Lost: {p['total_lost']} kg | Remaining: {p['remaining']} kg")
    elif command == "progress":
        p = get_progress()
        print(f"Start: {p['start_weight']} | Current: {p['current_weight']} | Target: {p['target_weight']}")
        print(f"Lost: {p['total_lost']} kg ({p['percentage']}%) | Remaining: {p['remaining']} kg")
