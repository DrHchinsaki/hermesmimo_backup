#!/usr/bin/env python3
"""
Calorie Tracker - Daily Calorie Management System
Tracks calorie intake and provides warnings
"""
import json
import os
from datetime import datetime

CALORIES_PATH = os.path.expanduser("~/.hermes/calorie_tracker/calories.json")

def load_data():
    if os.path.exists(CALORIES_PATH):
        with open(CALORIES_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {
        "daily_limit": 2117,
        "today": {"date": datetime.now().strftime("%Y-%m-%d"), "meals": [], "total_calories": 0, "remaining": 2117, "snacks": []},
        "history": [],
        "stats": {}
    }

def save_data(data):
    with open(CALORIES_PATH, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def reset_if_new_day(data):
    today = datetime.now().strftime("%Y-%m-%d")
    if data["today"]["date"] != today:
        if data["today"]["meals"] or data["today"]["snacks"]:
            data["history"].append(data["today"])
        data["today"] = {
            "date": today, "meals": [], "total_calories": 0,
            "remaining": data["daily_limit"], "snacks": []
        }
        save_data(data)
    return data

def add_meal(meal_type, food_items, calories):
    data = load_data()
    data = reset_if_new_day(data)
    meal = {"type": meal_type, "items": food_items, "calories": int(calories), "time": datetime.now().strftime("%H:%M")}
    data["today"]["meals"].append(meal)
    data["today"]["total_calories"] += int(calories)
    data["today"]["remaining"] = data["daily_limit"] - data["today"]["total_calories"]
    save_data(data)
    return meal, data["today"]

def get_status():
    data = load_data()
    data = reset_if_new_day(data)
    today = data["today"]
    remaining = today["remaining"]
    total = today["total_calories"]
    limit = data["daily_limit"]
    percentage = round((total / limit * 100) if limit > 0 else 0, 1)
    warning = None
    if remaining < 0:
        warning = "exceeded"
    elif percentage >= 90:
        warning = "critical"
    elif percentage >= 70:
        warning = "warning"
    return {"total_calories": total, "remaining": remaining, "daily_limit": limit, "percentage": percentage, "warning": warning}

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: calorie_tracker.py <add|status> [args]")
        sys.exit(1)
    command = sys.argv[1]
    if command == "add" and len(sys.argv) >= 5:
        meal, today = add_meal(sys.argv[2], sys.argv[3], sys.argv[4])
        print(f"Added: {meal['type']} - {meal['items']} ({meal['calories']} cal)")
        print(f"Total: {today['total_calories']} / {today['remaining']} remaining")
        if today['remaining'] < 0:
            print(f"WARNING: Over limit by {abs(today['remaining'])} calories!")
    elif command == "status":
        s = get_status()
        print(f"Limit: {s['daily_limit']} | Consumed: {s['total_calories']} ({s['percentage']}%) | Remaining: {s['remaining']}")
        if s['warning'] == 'exceeded':
            print(f"OVER LIMIT by {abs(s['remaining'])} calories!")
        elif s['warning'] == 'critical':
            print(f"CRITICAL: Only {s['remaining']} calories left!")
