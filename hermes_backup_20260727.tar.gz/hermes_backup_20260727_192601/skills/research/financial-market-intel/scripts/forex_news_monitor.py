#!/usr/bin/env python3
"""
Forex Factory News - Hot Stories Monitor
Fetches latest news stories from Forex Factory
"""
import urllib.request
import json
import re
from datetime import datetime

def fetch_forex_factory_news():
    """Fetch news from Forex Factory"""
    urls = [
        "https://www.forexfactory.com/news",
        "https://nfs.faireconomy.media/ff_news.json"
    ]
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
    }
    
    for url in urls:
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=30) as response:
                data = response.read().decode('utf-8')
                try:
                    return json.loads(data)
                except:
                    return parse_html_news(data)
        except:
            continue
    
    return {"error": "Could not fetch news"}

def parse_html_news(html):
    """Parse news from HTML response"""
    stories = []
    patterns = [
        r'class="news__title"[^>]*>([^<]+)<',
        r'class="story__title"[^>]*>([^<]+)<',
    ]
    
    for pattern in patterns:
        matches = re.findall(pattern, html)
        if matches:
            for match in matches[:10]:
                stories.append({'title': match.strip(), 'source': 'Forex Factory'})
            break
    
    return {"stories": stories, "count": len(stories)}

def check_for_new_stories():
    """Check for new stories"""
    data = fetch_forex_factory_news()
    if "error" in data:
        return data
    
    stories = data.get("stories", [])
    return {
        "stories": stories,
        "count": len(stories),
        "check_time": datetime.now().isoformat(),
        "has_new": len(stories) > 0
    }

if __name__ == "__main__":
    result = check_for_new_stories()
    if "error" in result:
        print(f"ERROR: {result['error']}")
    elif result["has_new"]:
        print(f"NEWS_FOUND: {result['count']} new stories")
        for story in result["stories"][:5]:
            print(f"- {story.get('title', 'N/A')}")
    else:
        print("NO_NEW_NEWS")
