#!/usr/bin/env python3
"""
Task Manager - Daily Task Management System
Manages tasks with reminders and tracking
"""
import json
import os
from datetime import datetime, timedelta

TASKS_PATH = os.path.expanduser("~/.hermes/task_manager/tasks.json")

def load_tasks():
    """Load tasks database"""
    if os.path.exists(TASKS_PATH):
        with open(TASKS_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"tasks": [], "completed": [], "pending": [], "stats": {}, "daily_logs": {}}

def save_tasks(data):
    """Save tasks database"""
    os.makedirs(os.path.dirname(TASKS_PATH), exist_ok=True)
    with open(TASKS_PATH, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def add_task(task_text, task_time=None, priority="normal"):
    """Add a new task"""
    db = load_tasks()
    
    task = {
        "id": len(db["tasks"]) + 1,
        "text": task_text,
        "time": task_time,
        "priority": priority,
        "status": "pending",
        "reminder_sent": False,
        "created_at": datetime.now().isoformat(),
        "date": datetime.now().strftime("%Y-%m-%d"),
        "completed_at": None
    }
    
    db["tasks"].append(task)
    db["pending"].append(task["id"])
    db["stats"]["total_tasks"] = len(db["tasks"])
    db["stats"]["pending_tasks"] = len(db["pending"])
    
    save_tasks(db)
    return task

def complete_task(task_id):
    """Mark a task as completed"""
    db = load_tasks()
    
    for task in db["tasks"]:
        if task["id"] == task_id:
            task["status"] = "completed"
            task["completed_at"] = datetime.now().isoformat()
            
            if task_id in db["pending"]:
                db["pending"].remove(task_id)
            db["completed"].append(task_id)
            
            db["stats"]["completed_tasks"] = len(db["completed"])
            db["stats"]["pending_tasks"] = len(db["pending"])
            total = db["stats"]["total_tasks"]
            db["stats"]["completion_rate"] = round((len(db["completed"]) / total * 100) if total > 0 else 0, 1)
            
            save_tasks(db)
            return task
    
    return None

def get_pending_tasks():
    """Get all pending tasks"""
    db = load_tasks()
    return [t for t in db["tasks"] if t["status"] == "pending"]

def get_tasks_needing_reminder():
    """Get tasks that need reminders (30 min before)"""
    db = load_tasks()
    now = datetime.now()
    reminders = []
    
    for task in db["tasks"]:
        if task["status"] == "pending" and task.get("time") and not task.get("reminder_sent"):
            try:
                task_time = datetime.strptime(f"{task.get('date', now.strftime('%Y-%m-%d'))} {task['time']}", "%Y-%m-%d %H:%M")
                diff = (task_time - now).total_seconds() / 60
                
                if 0 <= diff <= 30:
                    reminders.append(task)
            except:
                continue
    
    return reminders

def mark_reminder_sent(task_id):
    """Mark that reminder was sent for a task"""
    db = load_tasks()
    
    for task in db["tasks"]:
        if task["id"] == task_id:
            task["reminder_sent"] = True
            save_tasks(db)
            return True
    
    return False

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: task_manager.py <command> [args]")
        print("Commands: add, complete, pending, reminders, stats")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "add" and len(sys.argv) >= 3:
        task = add_task(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None)
        print(f"✅ Task #{task['id']}: {task['text']}")
    
    elif command == "complete" and len(sys.argv) >= 3:
        task = complete_task(int(sys.argv[2]))
        print(f"✅ Completed" if task else "❌ Not found")
    
    elif command == "pending":
        tasks = get_pending_tasks()
        for t in tasks:
            time_str = f" @ {t['time']}" if t.get('time') else ""
            print(f"📌 #{t['id']}: {t['text']}{time_str}")
    
    elif command == "reminders":
        tasks = get_tasks_needing_reminder()
        for t in tasks:
            print(f"🔔 #{t['id']}: {t['text']} @ {t['time']}")
    
    elif command == "stats":
        db = load_tasks()
        stats = db["stats"]
        print(f"📊 Total: {stats.get('total_tasks', 0)} | Done: {stats.get('completed_tasks', 0)} | Rate: {stats.get('completion_rate', 0)}%")
