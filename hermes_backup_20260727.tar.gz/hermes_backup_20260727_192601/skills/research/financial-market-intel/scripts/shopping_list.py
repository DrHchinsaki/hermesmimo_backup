#!/usr/bin/env python3
"""
Shopping List Manager
Simple grocery list management
"""
import json
import os
from datetime import datetime

LIST_PATH = "/data/.hermes/shopping_list/list.json"

def load_list():
    """Load shopping list"""
    if os.path.exists(LIST_PATH):
        with open(LIST_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"items": [], "completed": [], "history": []}

def save_list(data):
    """Save shopping list"""
    with open(LIST_PATH, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def add_item(item_name, quantity="1"):
    """Add item to list"""
    data = load_list()
    
    item = {
        "id": len(data["items"]) + 1,
        "name": item_name,
        "quantity": quantity,
        "added_at": datetime.now().isoformat()
    }
    
    data["items"].append(item)
    save_list(data)
    return item

def remove_item(item_id):
    """Remove item from list (mark as completed)"""
    data = load_list()
    
    for item in data["items"]:
        if item["id"] == item_id:
            data["items"].remove(item)
            item["completed_at"] = datetime.now().isoformat()
            data["completed"].append(item)
            data["history"].append(item)
            save_list(data)
            return item
    
    return None

def get_list():
    """Get current shopping list"""
    data = load_list()
    return data["items"]

def clear_list():
    """Clear all items"""
    data = load_list()
    data["completed"].extend(data["items"])
    data["items"] = []
    save_list(data)

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: shopping_list.py <command> [args]")
        print("Commands:")
        print("  add <item> [quantity]")
        print("  remove <item_id>")
        print("  list - show current list")
        print("  clear - clear all items")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "add" and len(sys.argv) >= 3:
        quantity = sys.argv[3] if len(sys.argv) > 3 else "1"
        item = add_item(sys.argv[2], quantity)
        print(f"Added: {item['name']} (x{item['quantity']})")
    
    elif command == "remove" and len(sys.argv) >= 3:
        item = remove_item(int(sys.argv[2]))
        if item:
            print(f"Removed: {item['name']}")
        else:
            print("Item not found")
    
    elif command == "list":
        items = get_list()
        if items:
            print("Shopping List:")
            for item in items:
                print(f"  #{item['id']}: {item['name']} (x{item['quantity']})")
        else:
            print("List is empty")
    
    elif command == "clear":
        clear_list()
        print("List cleared")
    
    else:
        print("Invalid command")
