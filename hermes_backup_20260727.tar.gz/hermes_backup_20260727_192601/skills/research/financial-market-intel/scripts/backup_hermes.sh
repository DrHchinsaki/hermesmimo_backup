#!/bin/bash
# Hermes Agent Backup Script
# Backs up memory, skills, config, and important files to GitHub

set -e

HERMES_HOME="${HERMES_HOME:-$HOME/.hermes}"
BACKUP_DIR="/tmp/hermes_backup_$(date +%Y%m%d_%H%M%S)"
ACCESS_TOKEN="${GITHUB_BACKUP_TOKEN}"
REPO_URL="https://github.com/DrHchinsaki/hermesmimo_backup.git"
BACKUP_FILE="hermes_backup_$(date +%Y%m%d).tar.gz"

echo "🔄 Starting Hermes backup..."

mkdir -p "$BACKUP_DIR"

# Backup key files
[ -d "$HERMES_HOME/memories" ] && cp -r "$HERMES_HOME/memories" "$BACKUP_DIR/memory"
[ -f "$HERMES_HOME/SOUL.md" ] && cp "$HERMES_HOME/SOUL.md" "$BACKUP_DIR/"
[ -f "$HERMES_HOME/config.yaml" ] && cp "$HERMES_HOME/config.yaml" "$BACKUP_DIR/"
[ -d "$HERMES_HOME/skills" ] && cp -r "$HERMES_HOME/skills" "$BACKUP_DIR/skills"
[ -f "$HERMES_HOME/cron/jobs.json" ] && mkdir -p "$BACKUP_DIR/cron" && cp "$HERMES_HOME/cron/jobs.json" "$BACKUP_DIR/cron/"
[ -d "$HERMES_HOME/scripts" ] && cp -r "$HERMES_HOME/scripts" "$BACKUP_DIR/scripts"

# Create archive
cd /tmp
tar -czf "$BACKUP_FILE" -C /tmp "hermes_backup_$(date +%Y%m%d_%H%M%S)"

# Push to GitHub
git config --global user.email "hermes-agent@backup"
git config --global user.name "Hermes Agent"

REPO_DIR="/tmp/hermesmimo_backup_repo"
rm -rf "$REPO_DIR"
git clone "https://${ACCESS_TOKEN}@github.com/DrHchinsaki/hermesmimo_backup.git" "$REPO_DIR" 2>/dev/null || {
    mkdir -p "$REPO_DIR"
    cd "$REPO_DIR"
    git init
    git remote add origin "https://${ACCESS_TOKEN}@github.com/DrHchinsaki/hermesmimo_backup.git"
}

cd "$REPO_DIR"
cp "/tmp/$BACKUP_FILE" .
git add .
git commit -m "Backup: $(date '+%Y-%m-%d %H:%M:%S')" --allow-empty
git push origin main 2>&1

# Cleanup
rm -rf "$REPO_DIR" "$BACKUP_DIR" "/tmp/$BACKUP_FILE"

echo "✅ Backup completed!"
