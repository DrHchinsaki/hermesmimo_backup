---
name: financial-market-intel
description: "Scheduled financial data collection, real-time event monitoring, and market impact analysis."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [finance, economic-calendar, forex, cron, summarization]
---

# Financial Market Intelligence

Collect, analyze, and deliver financial/economic data on a schedule. Covers API data collection, cron job setup, and multilingual summarization for traders and investors.

## Use When

- User wants scheduled economic news/calendar updates
- User wants financial data summarized from sources like Forex Factory
- User wants market intel delivered to Telegram/Discord/etc on a recurring basis
- User provides an example format for financial summaries
- User wants real-time notifications when economic events are released
- User wants market impact analysis comparing actual vs forecast results

## Data Sources

### Forex Factory Economic Calendar

**API Endpoint:** `https://nfs.faireconomy.media/ff_calendar_thisweek.json`

**Data Structure:**
```json
{
  "title": "CPI m/m",
  "currency": "USD",
  "impact": "High",  // High, Medium, Low
  "date": "2026-07-28T21:30:00-04:00",
  "forecast": "0.2%",
  "previous": "-0.7%"
}
```

**Filtering:** Focus on `impact: "High"` and `impact: "Medium"` events for actionable summaries.

**Currency Codes:** USD, EUR, GBP, JPY, CHF, CAD, AUD, NZD, CNY

## Cron Job Setup

### Critical Pitfalls

1. **Model must be configured** — Cron jobs fail with `RuntimeError: has no model configured`. Always set model via `cronjob action=update job_id=... model=<name>`.

2. **Provider name matters** — Use the exact provider name from your config. Common mistake: `"openai"` fails; correct is `"openai-api"` (check with `hermes model`).

3. **Script paths must be relative** — Scripts live in `~/.hermes/scripts/`. Use filename only: `script: "forex_factory_news.py"`, NOT absolute path.

### Setup Pattern

```python
# 1. Create data collection script at ~/.hermes/scripts/<name>.py
# 2. Create cron job
cronjob(action="create", 
        schedule="0 9 * * 0",  # Every Sunday 9am
        prompt="...",
        script="<name>.py",  # Relative path
        deliver="telegram")
# 3. Configure model
cronjob(action="update", job_id="<id>", model={"model": "gpt-4o", "provider": "openai-api"})
```

## Summarization Formats (Persian/Farsi)

### Format 1: Full Analysis (Detailed)

```markdown
## 📊 خلاصه اخبار اقتصادی هفته [tarikh]

### رویدادهای مهم:
#### [روز] [تاریخ]
- [نام رویداد] - [واحد پول]
  - اهمیت: 🔴 مهم / 🟡 متوسط
  - پیش‌بینی: [مقدار]
  - قبلی: [مقدار]
  - توضیح: [اهمیت رویداد]

### تحلیل و پیش‌بینی:
- تأثیر بر بازارهای مالی
- جفت‌ارزهای کلیدی (EURUSD, GBPUSD, USDJPY)
- تأثیر بر طلا و نفت

### نکات کلیدی:
- مهم‌ترین رویدادها
- ریسک‌ها و فرصت‌ها
```

### Format 2: Simple Event List (No Analysis) — PREFERRED

User explicitly corrected: "تحلیل رو هم نیاز ندارم فقط زیر هر کدوم از اخباری که وجود داره یک توضیح کوچیک بنویس"

This is the preferred format — brief impact notes only, NO full analysis section.

```markdown
## اخبار اقتصادی هفته [date]

### [Day Name] [Date]

**[Event Name]** - [Currency]
- اهمیت: [High/Medium]
- پیش‌بینی: [Forecast]
- قبل: [Previous]
- اگر بیشتر باشد: [brief impact on currency]
- اگر کمتر باشد: [brief impact on currency]

(Repeat for each event)
```

**Prompt pattern for simple format:**
```
Write a summary in PERSIAN. For EACH event, add a brief note about impact:
- Agar bishtar bashad: [brief impact]
- Agar kamtar bashad: [brief impact]
Keep explanations very short (one line each). No full analysis section.
```

**User correction:** "تحلیل رو هم نیاز ندارم" — Do NOT add analysis sections, just list events with brief "if higher/lower" impact notes under each.

### Style Guidelines

- Use emojis for visual hierarchy (🔴🟡🟢 for importance)
- Include currency flag emojis (🇺🇸🇪🇺🇬🇧🇯🇵)
- Professional, analytical tone
- Group events by date
- Highlight key implications for traders

## Example: FOMC Summary Pattern

When summarizing FOMC or central bank decisions:

1. **Decision:** Rate unchanged/changed, vote count
2. **Key Points:** Inflation outlook, economic strength, labor market
3. **Forward Guidance:** Future rate expectations, data dependence
4. **Market Impact:** Dollar, bonds, equities, commodities
5. **Trading Implications:** Specific pairs and assets to watch

## Scripts

- `scripts/forex_factory_fetcher.py` — Ready-to-use script for fetching Forex Factory data. Copy to `~/.hermes/scripts/` and use as cron job script.

## Real-Time Event Monitoring

### Pattern: Weekly Summary + Hourly Monitor

Set up two coordinated cron jobs:
1. **Weekly job** (Sunday 9am) — previews the week's events with times
2. **Hourly job** — checks if any events are happening now or just released

### Hourly Monitor Script

```python
#!/usr/bin/env python3
"""Check for events happening now or recently released."""
import urllib.request
import json
from datetime import datetime

def fetch_forex_factory():
    url = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
    })
    with urllib.request.urlopen(req, timeout=30) as response:
        return json.loads(response.read().decode('utf-8'))

def check_events():
    data = fetch_forex_factory()
    now = datetime.now()
    upcoming = []  # happening in next 30 min
    recent = []    # happened in last 30 min
    
    for event in data:
        if event.get('impact') not in ['High', 'Medium']:
            continue
        try:
            event_time = datetime.fromisoformat(
                event['date'].replace('Z', '+00:00')
            ).replace(tzinfo=None)
            diff_min = (event_time - now).total_seconds() / 60
            
            info = {
                'title': event['title'],
                'currency': event['currency'],
                'forecast': event.get('forecast', ''),
                'previous': event.get('previous', ''),
                'actual': event.get('actual', ''),
            }
            
            if 0 <= diff_min <= 30:
                info['status'] = 'publishing_now'
                upcoming.append(info)
            elif -30 <= diff_min < 0:
                info['status'] = 'just_released'
                recent.append(info)
        except:
            continue
    
    print(json.dumps({
        'has_notifications': len(upcoming) > 0 or len(recent) > 0,
        'upcoming': upcoming,
        'recent': recent
    }, ensure_ascii=False))
```

**Cron setup:**
```python
cronjob(action="create",
        schedule="every 60m",
        prompt="Check for economic events. If recent_events exist, analyze results and market impact. If no events, reply with nothing.",
        script="forex_event_monitor.py",
        deliver="telegram")
```

### Market Impact Analysis Logic

When an event releases, compare actual vs forecast:

| Event Type | Actual > Forecast | Actual < Forecast |
|------------|-------------------|-------------------|
| CPI/Inflation | Dollar ↑ (rate hike fear) | Dollar ↓ (rate cut hope) |
| NFP/Employment | Dollar ↑ (strong economy) | Dollar ↓ (recession fear) |
| GDP | Dollar ↑, Stocks ↑ | Dollar ↓, recession fear |
| Rate Decision | Dollar ↑↑ | Dollar ↓↓, Gold ↑ |
| Unemployment | Dollar ↑ (low = good) | Dollar ↓ (high = bad) |

**Prompt for analysis:**
```
Analyze the released economic event:
- Event: [title]
- Actual: [actual] vs Forecast: [forecast]
- Previous: [previous]

Provide:
1. Better/worse than expected?
2. Impact on EURUSD, USDJPY, Gold, Oil
3. Trading implication
```

## Multi-Job Orchestration

When setting up coordinated jobs (weekly + hourly):

1. **Weekly job** previews events and their scheduled times
2. **Hourly job** monitors for releases in real-time
3. **Both deliver to same channel** (e.g., Telegram)
4. **Hourly job should be silent when no events** — use prompt like "If no events, reply nothing"

This avoids spam: hourly job only notifies when something actually happens.

## Voice Summaries

Add voice (TTS) summaries to financial news delivery for users who prefer audio.

### CRITICAL: Voice Language Preference

**Users almost always prefer ENGLISH voice summaries over Persian.** Persian TTS quality is significantly worse than English across all providers (Hermes built-in, Gemini, Edge, etc.).

**Pattern:**
- Text summary → Persian (full analysis, detailed)
- Voice summary → English (concise, 1-minute radio style)

This hybrid approach gives users the best of both worlds: readable Persian text + clear English audio.

### Hermes Built-in TTS

Use the `text_to_speech` tool directly in cron job prompts:

```
After writing the Persian text summary, create an ENGLISH voice version:
- Write a 1-minute script (max 120 words English)
- Conversational radio-news tone
- Cover only the 3-4 most important events
- Use text_to_speech tool to generate audio
- Include MEDIA: path in your response
```

**Voice summary structure (English):**
```
Hello! Here's your weekly economic summary for [date].
Key events this week: On [day], [event] with forecast of [value].
Market analysis: [brief 1-2 sentence impact].
Key takeaway: [main trading implication].
Good luck with your trades!
```

### Prompt Pattern for Cron Jobs

When setting up a weekly financial news job with voice:

```python
cronjob(
    action="update",
    job_id="<id>",
    prompt="""
[existing Persian text summary instructions...]

2. SECOND, write an ENGLISH voice summary (max 1 minute):
   - Conversational tone, like radio news briefing
   - Cover only the 3-4 most important events
   - Max 120 words English
   - Format: "Hello! Here's your weekly economic summary..."
   
3. THEN use text_to_speech tool to convert the ENGLISH summary to audio
"""
)
```

### Pitfall: Voice Length

English speech is ~130-150 words/minute. Keep voice scripts concise:
- ❌ Detailed analysis with numbers and percentages (too long)
- ✅ "CPI came in at 3.5%, above expectations. Dollar strengthening." (concise)

### Gemini TTS API (Experimental)

Google AI Studio provides TTS models (`gemini-2.5-flash-preview-tts`, `gemini-3.1-flash-tts-preview`) but:
- May return 403 Forbidden if API key lacks TTS permissions
- Requires `responseModalities: ["AUDIO"]` in generation config
- Built-in Hermes TTS is more reliable for production cron jobs

If user specifically requests Gemini TTS, test with a simple call first before committing to it.

### Voice Summary Can Be Disabled

Users may initially request voice summaries but later decide they don't want them. Be prepared to:
1. Remove TTS instructions from cron job prompts
2. Keep text-only summaries
3. Update job via `cronjob action=update` to remove voice-related instructions

## Model Selection for Financial Analysis

### User Preference: Complex Tasks = Best Models

Users typically consider economic/financial analysis as "complex work" and want the best available models for it. Set expectations during setup:

| Task Complexity | Recommended Model | Provider |
|-----------------|-------------------|----------|
| 📊 Economic analysis, market summaries | Best available (e.g. `gemini-2.5-pro`) | Gemini Pro |
| 🔔 Real-time event monitoring | Fast model (e.g. `gemini-2.5-flash`) | Gemini Pro |
| 💬 Simple alerts, notifications | Any capable model | Any |

**Pattern:** When user has a Pro/paid account for a provider, use the best models for complex analysis tasks. Use faster/cheaper models for routine monitoring.

### OpenRouter Free Tier Limitation

OpenRouter free accounts can ONLY use models tagged `:free`. Paid models will fail with authentication errors.

**Available free models (as of 2026):**
- `nvidia/nemotron-3-ultra-550b-a55b:free` — Best for long analysis (1M context)
- `nvidia/nemotron-3-super-120b-a12b:free` — Good for summaries (262K)
- `google/gemma-4-31b-it:free` — Good for code (262K)
- `openai/gpt-oss-20b:free` — General use (131K)

**Do NOT use on free tier:** `anthropic/claude-*`, `openai/gpt-4*`, any model without `:free` suffix.

## Trading Journal System

For users who want to track their trades and analyze performance over time.

### Data Structure

Store trades in `~/.hermes/trading_journal/trades.json`:

```json
{
  "trades": [
    {
      "id": 1,
      "pair": "EURUSD",
      "direction": "BUY",
      "entry": 1.0850,
      "tp": 1.0900,
      "sl": 1.0800,
      "exit": 1.0900,
      "result": "WIN",
      "pips": 50,
      "strategy": "Breakout",
      "mindset": "Focused and calm",
      "screenshot": "path/to/screenshot.jpg",
      "status": "closed",
      "opened_at": "2026-07-26T10:00:00",
      "closed_at": "2026-07-26T14:00:00"
    }
  ],
  "stats": {
    "total_trades": 10,
    "wins": 6,
    "losses": 4,
    "win_rate": 60.0,
    "total_pips": 250
  },
  "strategies": {},
  "pairs": {}
}
```

### User Input Format

When user sends a new position, parse this format:

```
📌 New Position:
💰 Pair: EURUSD
📊 Type: BUY/SELL
🎯 Entry: 1.0850
🎯 TP: 1.0900
🛑 SL: 1.0800
📝 Strategy: Breakout
💭 Mindset: Focused
📸 Screenshot: [attached]
```

### Closing a Position

When user announces result:

```
✅ Position Result:
💰 Pair: EURUSD
🎯 Exit: 1.0900
📈 Result: TP ✅
💰 Pips: +50
📝 Notes: [optional]
```

### CRITICAL: Do NOT Analyze Trades at Entry

**User correction:** "اسکرین شات رو برات نفرستادم که تحلیل کنی، من ازت تحلیل نمی‌خوام برای معاملاتم، بهت دادم تا ثبت کنی که بعداً بتونیم آنالیز کنیم پوزیشن های من رو"

When user sends a new position with screenshot:
1. ✅ **RECORD** the trade data (entry, TP, SL, strategy, mindset, screenshot)
2. ✅ Copy screenshot to `~/.hermes/trading_journal/screenshots/`
3. ❌ **DO NOT** provide technical analysis, RSI readings, or trading advice
4. ❌ **DO NOT** analyze the screenshot beyond noting it exists
5. ✅ Simply confirm: "ثبت شد!" with the recorded data table

The user will request analysis later when they want it. Recording is the ONLY job at position entry.

### Report Generation

Generate reports on demand:
- **Summary:** Total trades, win rate, total pips
- **Strategy Analysis:** Which strategies perform best
- **Pair Analysis:** Which currency pairs perform best
- **Mindset Analysis:** Correlation between mindset and results

### Scripts

- `scripts/add_trade.py` — Add/close trades, view stats
- `scripts/generate_report.py` — Generate various reports

## Forex Factory News - Hot Stories

Monitor the "News - Hot Stories" section for breaking financial news.

**Different from Economic Calendar:** This is for news articles/stories, not scheduled events.

### Script Pattern

```python
#!/usr/bin/env python3
"""Fetch Forex Factory Hot Stories"""
import urllib.request
import json

def fetch_news():
    urls = [
        "https://www.forexfactory.com/news",
        "https://nfs.faireconomy.media/ff_news.json"
    ]
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
    }
    for url in urls:
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=30) as response:
                return json.loads(response.read().decode('utf-8'))
        except:
            continue
    return {"stories": []}
```

### Cron Setup

Run every 2 hours to catch breaking news:

```python
cronjob(action="create",
        schedule="every 2h",
        prompt="Check for new Forex Factory stories. If new stories exist, list them with brief market impact. If no new stories, reply with nothing.",
        script="forex_news_monitor.py",
        deliver="telegram")
```

### Delivery Format

```
📰 **FOREX FACTORY - NEW STORIES**

🔄 3 New Stories Found

1️⃣ **Fed Officials Signal Rate Pause**
📌 Source: Forex Factory
💡 Impact: Dollar may weaken if rate cuts expected

2️⃣ **China PMI Beats Expectations**
📌 Source: Forex Factory
💡 Impact: Risk-on sentiment, AUD/CNY strength

⚠️ Monitor: FOMC, CPI, NFP, GDP, Interest Rates

#forexnews
```

## Message Hashtag Convention

**CRITICAL:** Hashtag usage differs between DM and group messages.

### Group Messages
- **ONLY use `#News`** for all group messages
- Do NOT use other hashtags in group
- User's full group hashtag set (for reference, but only use #News): `#Chinaski`, `#Potato`, `#Analysis`, `#News`, `#Note`, `#Trade`, `#Backtest`, `#Update`, `#Quotes`

### DM Messages (Private Chat)
Use full hashtag set for easy filtering:

| Hashtag | Usage |
|---------|-------|
| `#econweekly` | Weekly economic calendar summary |
| `#econalerts` | Real-time economic event alerts |
| `#forexnews` | Forex Factory Hot Stories |
| `#backup` | Backup job reports |
| `#trading` | Trading journal updates |
| `#weight` | Weight check-in and progress |
| `#calories` | Calorie tracking (all meals) |
| `#dailytasks` | Morning task check-in |
| `#reminder` | Advance reminders |
| `#dailyreport` | Evening completion report |
| `#hermes` | General Hermes updates |
| `#shopping` | Shopping/grocery list items |
| `#anniversary` | Monthly anniversary reminders |
| `#birthday` | Birthday reminders |

### Implementation

For cron jobs that deliver to BOTH DM and group:
- DM gets full hashtag
- Group gets only `#News`

For cron jobs that deliver ONLY to group:
- Use only `#News`

### User Benefit

User can search in Telegram:
- `#forexnews` — See only breaking news (DM)
- `#News` — See all news in group
- `#trading` — See only trading journal updates (DM)

## Telegram Group Privacy

**CRITICAL:** Group messages are ONE-WAY only (send only).

- Bot SENDS messages to group ✅
- Bot does NOT read/monitor group messages ❌
- User communicates with bot via DM only
- If user wants to send something to group, they tell bot in DM

**Pattern:** User says "توی گروه این رو بفرست: [message]" → Bot sends to group.

## Provider Troubleshooting

### Common Errors

| Error | Cause | Solution |
|-------|-------|----------|
| `HTTP 403: Project denied access` | API key lacks permissions | Check API key scope, enable API in console |
| `HTTP 429: Quota exceeded` | Rate limit or billing issue | Upgrade plan or wait |
| `RuntimeError: has no model configured` | Cron job missing model | Add model via `cronjob action=update` |
| `Unknown provider 'openai'` | Wrong provider name | Use `openai-api` not `openai` |

### OpenRouter Free Tier Rules

- ONLY models with `:free` suffix work
- Paid models fail silently or with auth errors
- Good free models: `nvidia/nemotron-3-*:free`, `google/gemma-4-*:free`

### Google Gemini API Issues

- API key may be for wrong service (AI Studio vs Generative Language)
- Project may need API enabled in Google Cloud Console
- Quota limits apply even with Pro accounts
- **Workaround:** Use OpenRouter free models instead

#### Error Code Diagnosis

| HTTP Code | Error Message | Meaning | Action |
|-----------|--------------|---------|--------|
| `401 UNAUTHENTICATED` | `ACCESS_TOKEN_TYPE_UNSUPPORTED` | Google AI Studio API key used with Generative Language API — these are different services with different auth mechanisms | Key is useless for Gemini cron jobs. Switch provider. |
| `403` | `Your project has been denied access` | API key found but project lacks Generative Language API permissions | Enable API in Google Cloud Console, or switch provider. |
| `429` | `Quota exceeded / Rate limit` | Billing issue or free tier exhausted | Wait or upgrade plan. |

**401 is terminal** for AI Studio keys — they are OAuth2-only and cannot be used as API keys for the Gemini text generation API. Do not retry. Switch provider immediately.

## Task Management with Reminders

For users who want daily task tracking with automatic reminders.

### Architecture: Three Cron Jobs

1. **Morning Check-in** (9 AM daily) — Asks user for today's tasks
2. **Reminder Checker** (every 30 min) — Sends reminders 30 min before task time
3. **Evening Report** (10 PM daily) — Summarizes completion status

### Data Structure

Store tasks in `~/.hermes/task_manager/tasks.json`:

```json
{
  "tasks": [
    {
      "id": 1,
      "text": "Team meeting",
      "time": "10:00",
      "status": "pending",
      "reminder_sent": false,
      "date": "2026-07-26",
      "created_at": "2026-07-26T09:00:00"
    }
  ],
  "stats": {
    "total_tasks": 5,
    "completed_tasks": 3,
    "pending_tasks": 2,
    "completion_rate": 60.0
  }
}
```

### Morning Check-in Pattern

```python
cronjob(
    action="create",
    schedule="0 9 * * *",
    prompt=\"\"\"Good morning! Ask the user what important tasks they have today.

Send this message:
"Good morning [Name]!

What important tasks do you have today?

Send me your task list with times, for example:
- 10:00 Team meeting
- 14:00 Client call
- No time: Learn Python

I will remind you and give you a report at night!"

After user responds, add each task using the task_manager.py script.
\"\"\",
    deliver="telegram"
)
```

### Reminder Checker Pattern

**User preference:** Some users prefer reminders every 2 hours instead of every 30 minutes (less intrusive). Ask during setup and adjust schedule accordingly.

```python
cronjob(
    action="create",
    schedule="every 30m",  # Or "every 120m" for less frequent reminders
    prompt="""Check for tasks needing reminders.

Run: python3 ~/.hermes/task_manager/scripts/task_manager.py reminders

If tasks need reminders, send:
"Reminder: [task text] is scheduled for [time]. 30 minutes remaining!"

Then mark reminder sent.

If no reminders, reply with nothing.
\"\"\",
    deliver="telegram"
)
```

### Evening Report Pattern

```python
cronjob(
    action="create",
    schedule="0 22 * * *",
    prompt=\"\"\"End of day! Check task completion.

1. Get stats: python3 task_manager.py stats
2. Get pending: python3 task_manager.py pending

Send summary:
"Night Report:

Completed: [number]
Pending: [number]
Rate: [percentage]%

Pending tasks:
- [list]

Did you complete these? Reply with 'done 1,3,5' to mark complete."

Wait for user response and update tasks.
\"\"\",
    deliver="telegram"
)
```

### User Input Format

**Morning (tasks with times):**
```
- 10:00 Team meeting
- 14:00 Client call
- No time: Learn Python
```

**Evening (completion):**
```
done 1,3,5
```

### Hashtag Convention

| Hashtag | Usage |
|---------|-------|
| `#dailytasks` | Morning task check-in |
| `#reminder` | 30-minute advance reminders |
| `#dailyreport` | Evening completion report |

## Personal Health & Productivity Tracking

For users who want automated health tracking (weight, calories, daily habits) with reminders.

### Architecture: Multiple Coordinated Cron Jobs

| Job | Schedule | Purpose |
|-----|----------|---------|
| Weight Check | 8 AM daily | Ask for weight, record, show progress |
| Breakfast Check | 7 AM daily | Ask what user ate, estimate calories |
| Lunch Check | 1 PM daily | Ask what user ate, estimate calories |
| Dinner Check | 8 PM daily | Ask what user ate, estimate calories |
| Snack Check | 10 PM daily | Ask about snacks, final daily summary |
| Morning Tasks | 9 AM daily | Ask for today's tasks + auto-add mandatory health tasks |
| Reminder Checker | Every 30 min | Remind 30 min before scheduled tasks |
| Evening Report | 10 PM daily | Task completion report |

### Weight Tracking System

**Goal tracking:** Store start weight, target weight, and daily entries.

**Data structure** (`~/.hermes/weight_tracker/weight.json`):
```json
{
  "goal": {"start_weight": 110, "target_weight": 80},
  "entries": [
    {"weight": 108.5, "date": "2026-07-26", "time": "08:15"}
  ],
  "stats": {"total_lost": 1.5, "percentage": 5.0}
}
```

**Progress prompt pattern:**
```
Scale time! What's your weight today?
Progress: [start] → [current] → [target]
Lost: [amount] ([percentage]%)
Remaining: [amount] kg
Just send the number (e.g., '108.5')
```

**After user responds:**
```bash
python3 ~/.hermes/weight_tracker/scripts/weight_tracker.py add [weight]
```

### Calorie Tracking System

**Daily limit:** Store user's calorie budget (e.g., 2117 cal/day).

**Data structure** (`~/.hermes/calorie_tracker/calories.json`):
```json
{
  "daily_limit": 2117,
  "today": {
    "date": "2026-07-26",
    "meals": [
      {"type": "breakfast", "items": "2 eggs, toast", "calories": 220, "time": "07:15"}
    ],
    "total_calories": 220,
    "remaining": 1897
  }
}
```

**Warning levels:**
| Remaining | Status | Message |
|-----------|--------|---------|
| > 30% | ✅ Normal | Show remaining |
| 10-30% | ⚠️ Caution | "Getting close to limit" |
| < 10% | 🔴 Critical | "Only X calories left!" |
| < 0 | 🚫 Over | "Over limit by X calories!" |

**Calorie estimation pattern:** When user describes food, estimate calories based on common values:
- Eggs: ~70 cal each
- Toast: ~80 cal
- Rice (1 cup): ~200 cal
- Chicken breast: ~165 cal per 100g
- Salad: ~50-100 cal
- Coffee (black): ~5 cal
- Coffee with milk: ~50 cal

**End-of-day summary:**
```
🌙 Calorie Report:
- Breakfast: 220 cal
- Lunch: 650 cal
- Dinner: 700 cal
- Snacks: 150 cal
Total: 1725 / 2117 cal ✅
```

### Daily Mandatory Health Tasks

Some tasks are non-negotiable and should be auto-added every day:

**Pattern:** In morning task check-in prompt, always include:
```
Your daily mandatory tasks:
1. Walking/Treadmill - 20 minutes minimum
2. Exercise/Workout

What other tasks do you have today?
```

**Evening report emphasis:**
```
Daily Mandatory Tasks:
1. Walking/Treadmill: [DONE/PENDING]
2. Exercise/Workout: [DONE/PENDING]
```

### Hashtags for Health Tracking

| Hashtag | Usage |
|---------|-------|
| `#weight` | Weight check-in and progress |
| `#calories` | Calorie tracking (all meals) |
| `#dailytasks` | Morning task check-in |
| `#reminder` | 30-minute advance reminders |
| `#dailyreport` | Evening completion report |

### User Interaction Flow

**Morning (8-9 AM):**
1. Weight check (8:00) → User sends number
2. Breakfast check (7:00) → User describes meal
3. Task check-in (9:00) → User lists tasks with times

**Throughout day:**
- Reminders 30 min before scheduled tasks
- Lunch check (1:00) → User describes meal
- Calorie warnings if approaching limit

**Evening (8-10 PM):**
- Dinner check (8:00) → User describes meal
- Snack check (10:00) → Any additional food?
- Task completion report (10:00) → What got done?

### Scripts

- `scripts/weight_tracker.py` — Weight entry, progress, history
- `scripts/calorie_tracker.py` — Meal logging, calorie calculation, warnings
- `scripts/task_manager.py` — Task CRUD, reminders, completion tracking

## Telegram Group Delivery

When user wants messages sent to both their DM and a Telegram group:

### Configuration
```python
cronjob(
    action="update",
    job_id="<id>",
    deliver="origin,telegram:-1004281458610"
)
```

### Critical: Bot Must Be Added to Group
Before group delivery works, the bot must be added as a member:
1. Open Telegram group
2. Tap group name → Add Members
3. Search for bot username and add

**Error if not added:** `Forbidden: bot is not a member of the supergroup chat`

### Silent Mode for No-News (CRITICAL)
Avoid spam by not sending when nothing happens. Use `[SILENT]` to suppress ALL delivery (both DM and group):

```
If no news, respond with EXACTLY:
[SILENT]

Do NOT add any other text when there are no news.
```

**Why [SILENT] not [NO_NEWS]:**
- `[NO_NEWS]` or `[NO_EVENTS]` may still trigger delivery to the group
- `[SILENT]` is the official Hermes token that suppresses ALL delivery
- User explicitly corrected: "وقتی NO_EVENT هست نمی‌خوام پیامی به گروه ارسال بشه"

**Full details:** See `references/telegram-group-delivery.md`

## Related Skills

- `blogwatcher` — RSS/feed monitoring (different data source pattern)
- `polymarket` — Prediction market data
- `scheduled-automation` — General cron patterns and backup automation

## Shopping List System

Simple persistent list management for groceries/items.

### User Interaction

**Add items:**
```
#shopping Shir, tokhm-e morgh, nan
```

**Remove (when purchased):**
```
List-e kharid: shomare 1 va 2 ro kharidam
```

**View list:**
```
List-e kharid chiye?
```

### Hashtag: `#shopping`

### Script
- `scripts/shopping_list.py` — Add/remove/list items

## Date-Based Reminders

For recurring annual/monthly reminders (anniversaries, birthdays).

### Monthly Reminder Pattern

```python
cronjob(
    action="create",
    schedule="30 18 16 * *",  # 16th of every month at 20:00 Tehran
    prompt="Send romantic reminder...",
    deliver="telegram"
)
```

### Annual Reminder Pattern

Remind on multiple days leading up to the event:

```python
cronjob(
    action="create",
    schedule="30 18 8,9,10,11 1 *",  # Jan 8-11 at 20:00 Tehran
    prompt="Birthday reminder...",
    deliver="telegram"
)
```

### Persian Calendar Dates

For users in Iran, important dates are often in Persian calendar:
- Dey 21 ≈ January 11 (Gregorian)
- Remind from Dey 18 (≈ January 8) for 4 days

### Hashtags: `#anniversary`, `#birthday`
