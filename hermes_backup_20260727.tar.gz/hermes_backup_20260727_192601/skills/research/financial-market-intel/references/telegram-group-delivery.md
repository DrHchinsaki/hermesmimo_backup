# Telegram Group Delivery Reference

## Configuration

### Group Chat ID
```
-1004281458610
```

### Deliver Format
```python
deliver="origin,telegram:-1004281458610"
```

## Privacy Rules

1. **ONE-WAY delivery only** — Bot sends TO group, does NOT read FROM group
2. **User communicates via DM only** — All interaction happens in private chat
3. **Group messages use #News ONLY** — No other hashtags in group

## Bot Membership Requirement

Before group delivery works, bot MUST be added as member:
1. Open Telegram group
2. Tap group name → Add Members
3. Search for bot username and add

**Error if not added:** `Forbidden: bot is not a member of the supergroup chat`

## Silent Mode

To avoid spam when no news:
```
If no news, reply with EXACTLY: [NO_NEW_NEUES]
```

## Jobs Configured for Group Delivery

| Job | Schedule | Purpose |
|-----|----------|---------|
| Forex Factory News Monitor | Every 2 hours | Breaking news |
| Economic Event Real-time Monitor | Every 1 hour | Event alerts |
| Weekly Forex Factory Economic News | Sunday 21:00 | Weekly summary |

## Testing Delivery

After configuring group delivery, test with:
```python
cronjob(action="run", job_id="<id>")
```

Check both the user DM and group for the message.
